<div class="modal fade" id="selSubModal" role="dialog" style="margin-top: 10rem;"  data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog modal-xs">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-info"></span> Select Student's Subject</h4>
			</div>
			<div class="modal-content">
				
			</div>
			<div class="modal-footer">
				<!-- <button type="button" class="btn btn-success" id='submitSub'><span class="glyphicon glyphicon-ok"></span> Continue</button> -->
				<button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
			</div>
				</form>
		</div>
	</div>
</div>