<?php
	include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];
	$fac = $_POST['fac'];
	$grade='';
?>
	<select class="form-control" id="sAtd" style="margin-bottom: 10px;">
				<option selected disabled>Subjects</option>
	<?php
		$x=0;
		$resSbjcts = mysqli_query($mysqli, "SELECT * FROM subjects WHERE faculty = '$fac' GROUP BY subject");
		while($rSbjtcs = mysqli_fetch_assoc($resSbjcts)){
			?> 
				<option value=<?php echo $rSbjtcs['row']; ?> > <?php echo $rSbjtcs['subject']; ?> </option>
			<?php
			$grade = $rSbjtcs['grade'];
			$array_subjects[$x] = $rSbjtcs['row'];
			$x++;
		}
		?>
			<option value="allSubjects">All Subjects</option>
		<?php
	?>
	</select>
	<script>
		document.getElementById('gradeLevel').value = '<?php echo $grade ?>';
		var subject_Array = <?php echo "['".implode("','", $array_subjects)."']" ?>
	</script>