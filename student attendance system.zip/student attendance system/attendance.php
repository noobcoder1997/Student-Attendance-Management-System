<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];

	
	$array_subjects=[];
	$grade="";	
?>
<style>
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}
</style>
<div class="container">
	<div class='row'>
		<div class="col-md-12">
			<h3>Attendance</h3>
			<div class="alert alert-info" style="margin-bottom: 10px;">
				<div class="form-group">
					<h4><i class="glyphicon glyphicon-check"></i> Have an Attendance!</h4>
				</div>
				<div class="row">
					<div class="col-md-12">
						<?php
							if($position == "Super Administrator"){
						?>
						    <select class="form-control" id="facAtd" type="text"  placeholder="Instructor" onchange="selectFaculty()" required style="margin-bottom: 10px;">
						      <option value='' selected disabled>Instructor</option>
						      <?php
						        $facRes0 = mysqli_query($mysqli, "SELECT * FROM users WHERE status = 1");
						        while ($r = mysqli_fetch_assoc($facRes0)) {

						        //   if($row == $r['row']){
						        //   	// echo "<option value=$r[row]>$r[name] - (You)</option> ";
						        //   }
						        //   else{
						          	echo "<option value=$r[row]>$r[name]</option> ";
						        //   }
						        }
						      ?>
						    </select>
							<div id="-sAtd">
								<select class="form-control"  style="margin-bottom: 10px;">
									<option selected disabled>Subjects</option>
								</select>
							</div>
							<div class="col-m-12">
								<input type="date" id="attendance-date" class="form-control">
							</div>
						<?php 
							}
						?>
						<?php
							if($position == "Administrator"){
						?>
						    <select class="form-control" id="sAtd" style="margin-bottom: 10px;" >
								<option value="Subjects" selected disabled>Subjects</option>
								<?php
									$x=0;
									$resSbjcts = mysqli_query($mysqli, "SELECT * FROM subjects WHERE faculty = '$row' ");
									while($rSbjtcs = mysqli_fetch_assoc($resSbjcts)){
										?> 
											<option value=<?php echo $rSbjtcs['row']; ?> > <?php echo $rSbjtcs['subject']; ?> </option>
										<?php
										$grade = $rSbjtcs['grade'];
										$array_subjects[$x] = $rSbjtcs['row'];
										$x++;
									}
								?>
								<option value="allSubjects">All Subjects</option>
							</select>
						<?php 
							}
						?>
						<div class="col-sm-12" id="selected_subjects"><!--Subjects--></div>
					</div>
					<input id="gradeLevel" type="hidden">

					<div class="col-md-12">
						<label><b style="color:darkred">Note:</b>&nbsp;Please make sure to enter the same Level of your choice.<i style="color:red">*</i></label>
						<br>
						<button value='SELECT' class='btn btn-primary form-control' id='btn-sel' onclick="selSub()" style="margin-bottom: 10px;" type="button" ><i class="glyphicon glyphicon-ok"></i>&nbsp;<strong>Select</strong></button>
						<button value='CLEAR' class='btn btn-warning form-control' id='btn-ref' onclick="selRef()" style="margin-bottom: 10px;display: none;" type="button" ><i class="glyphicon glyphicon-remove"></i>&nbsp;<strong>Clear/Cancel</strong></button>
					
					</div>
				</div>
				<span id='alert-insufficient-data' style="width:100%"></span>
				<span id='alert-error-id' style="width:100%"></span>
				<div class="row" id="modalData"></div>
			</div>		
		</div>
	</div>
	<?php
		$subjectQuery = mysqli_query($mysqli, "SELECT * FROM subjects WHERE faculty = '$row' ");
		while($result = mysqli_fetch_assoc($subjectQuery)){
			?>
				<div class="col-sm-3" style="margin-top: 10px;">
					<input type="radio" name="radio-subject" id="radio<?php echo $result['row'];?>" onclick="radioChecked('<?php echo $result['row'];?>')" style="height: 10px; width: 10px; padding: 1px; margin-top: 5px;"><label for="radio<?php echo $result['row'];?>" style="margin-right:10px">&nbsp;&nbsp;<?php echo $result['subject'];?></label>
				</div>
			<?php
		}
	?>
	<script>
		function radioChecked(subject){
			dateNow = "<?php echo date('M-d-Y'); ?>";
			facId = "<?php echo $row; ?>";
			$.ajax({
				data: 'subject='+subject+"&facId="+facId+"&date="+dateNow,
				method: 'post',
				url: 'attendanceFilteredSubjects.php',
			}).done( function (data){
				$('#curdate').html('')
				$('#curdate').html(data);
			});
		}
	</script>
	<div class="row"><br></div>
	<div class="row" id="curdate">
		<div class="col-md-12">
			<div class="table-responsive">
			<table id="datatable-daily-attendance" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th></th>
							<th>Student's Name</th>
							<th>Grade</th>
							<th>Subject</th>
							<th>Status</th>
							<?php 
								if($position == "Super Administrator") { 
									echo "<th>Teacher</th>"; 
								}
							?>
							<!-- <th><center>Edit</center></th>
							<th><center>Delete</center></th> -->
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th></th>
							<th>Student's Name</th>
							<th>Grade</th>
							<th>Subject</th>
							<th>Status</th>
							
							<?php 
								if($position == "Super Administrator") { 
									echo "<th>Teacher</th>"; 
								}
							?>
							<!-- <th><center>Edit</center></th>
							<th><center>Delete</center></th> -->
						</tr>
					</tfoot>
					<tbody id="curdate">
						<?php
							$current_date = date('M-d-Y');
							$attResult = '';
							if ($position == "Administrator") { $attResult = mysqli_query($mysqli, "SELECT * from attendance WHERE attendance_date = '$current_date' AND faculty = '$row' "); }
							else{ $attResult = mysqli_query($mysqli, "SELECT * from attendance WHERE attendance_date = '$current_date' "); }
							while ($r = mysqli_fetch_assoc($attResult)){
								$sbjctResult = mysqli_query($mysqli, "SELECT subject from subjects WHERE faculty = '$r[faculty]' AND row = '$r[subject]' ");				
								$stdtResult = mysqli_query($mysqli, "SELECT * from students WHERE id = '$r[studentId]' ");
								$s = mysqli_fetch_assoc($stdtResult);	
								$sbjct = mysqli_fetch_assoc($sbjctResult);
								$mn;
								if(isset($s['mn'])){
									$mn =$s['mn'];
								}
								else{
									$mn='';
								}
								if(isset($sbjct['subject']) == null){
									echo "<tr>
										<td> $s[id] </td>
										<td> <b>$s[ln]</b>, $s[fn] ".strtoupper($mn[0]).".</td>
										<td> Grade $r[grade] </td>
										<td> --No Subject-- </td>";	
								}
								if($mn == ''){
									echo "<tr>
										<td> $s[id] </td>
										<td> <b>$s[ln]</b>, $s[fn] </td>
										<td> Grade $r[grade] </td>
										<td> $sbjct[subject] </td>";	
								}
								else{
									echo "<tr>
										<td> $s[id] </td>
										<td> <b>$s[ln]</b>, $s[fn] ".strtoupper($mn[0]).".</td>
										<td> Grade $r[grade] </td>
										<td> $sbjct[subject] </td>";	
								}
										if($r['status'] == 0){
											echo "<td> <a class='btn btn-primary btn-xs btn-block btn-status'>Present</a> </td>";
										}if($r['status'] == 1){
											echo "<td> <a class='btn btn-danger btn-xs btn-block btn-status'>Absent</a> </td>";
										}if($r['status'] == 2){
											echo "<td> <a class='btn btn-warning btn-xs btn-block btn-status'>Excused</a> </td>";
										}
										if($position == "Super Administrator"){
											$tchrQry = mysqli_query($mysqli, "SELECT name FROM users WHERE row = '$r[faculty]' ");
											while($t=mysqli_fetch_assoc($tchrQry))
											echo "<td> $t[name]</td>";
										}
								// echo 	"<td>
								// 			<center>
								// 				<button class='btn btn-warning btn-xs' data-toggle='modal' data-target='#editStAttendance".//$r['row']."'>
								// 					<span class='glyphicon glyphicon-pencil'></span> Edit
								// 				</button>
								// 			</center>
								// 		</td>
								// 		<td>
								// 			<center>
								// 				<button class='btn btn-danger btn-xs' data-toggle='modal' data-target='#deltStAttendance".//$r['row']."'>
								// 					<span class='glyphicon glyphicon-trash'></span> Delete
								// 				</button>
								// 			</center>
								// 		</td>
								// 	</tr>
								//	";
						?>
						<?php //include 'deleteAttendanceModal.php'; ?>
						<?php //include 'updateAttendanceModal.php'; ?>
						<?php				 
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	function speakAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Student's  Attendance  was  Added Successfully!";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakErrorAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Student's attendance was already recorded!";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakEmptyAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Please choose and fill Student's attendance status.";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakEmptyTeacherAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Please Select an Instructor for the record.";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}
	function speakEmptySubjectAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Please Select a Subject for the record.";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}
</script>
<script>  
	$('#datatable-daily-attendance').dataTable();
	$("[data-toggle=tooltip]").tooltip();
</script>
<script type="text/javascript">	
	var position = $('#position-id').val();
	var afacNo;
	var numrows;
	var id = [];
	var st = [];
	let status_col_0 =[];
	let id_col_0 = [];
	var filtered_ids;
	var filtered_sts;
	var subjectArray = <?php echo "['".implode("','", $array_subjects)."']" ?>;

	function selectFaculty() {
		$('#admin_Id').val();
		var fac = $('#facAtd').val();
		console.log(fac);
		var sfac = "fac="+fac;
		$.ajax({
			method: 'post',
			data: sfac,
			url:'showSubject.php',
		}).done( function(data){
			// console.log(data);
			$('#-sAtd').html(data);
		});
	}

	function selRef(){
		$('#btn-sel').show();
		$('#facAtd').val('');
		$('#sAtd').val('Subjects');
		$('#sGAtd').val('');
		$('#modalData').html('');
		$('#btn-ref').hide();	

		del_Array_Values();
	}

	function selSub(){
		if(position == "Super Administrator"){
			var selected_grade = $('#gradeLevel').val(); 
			var selected_subject = $('#sAtd').val(); 
			var selected_teacher = $('#facAtd').val();
			var selectElement = document.querySelector('#sAtd');
			if(selectElement != null){

				var output = selectElement.options[selectElement.selectedIndex].value;

				if(selected_grade == null ||  selected_subject == null || selected_teacher == null){
					$('#btn-ref').hide();
					$('#btn-sel').show();
				}
					if(output == "Subjects"){
						$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i> No Subject/s are Selected!</div>');
						$('#alert-error-id').show(100).delay(2000).hide(100);
					}
					else{
						
						var sub ;
						if(output == "allSubjects"){
							sub = "selected_grade="+selected_grade+"&selected_teacher="+selected_teacher;
							// alert(subjectArray)
						}
						else{
							sub = "selected_grade="+selected_grade+"&selected_teacher="+selected_teacher;
							// alert(subjectArray)
						}
						$.ajax({
							url:'showStudentForAttendance.php',
							type:'post',
							data:sub,
						}).done( function(data){
							$('#modalData').html(data);
							$('#btn-ref').show();
							$('#btn-sel').hide();

						});
					}
				}
				else if(position == "Administrator"){
					var selected_grade = "<?php echo $grade?>"; 
					var selected_subject = $('#sAtd').val(); 
					var selected_teacher = $('#faculty-id').val();
					var selectElement = document.querySelector('#sAtd');
					var output = selectElement.options[selectElement.selectedIndex].value;
					if(selected_grade == null ||  selected_subject == null || selected_teacher == null){
						$('#btn-ref').hide();
						$('#btn-sel').show();
					}
					if(output == "Subjects"){
						$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i> No Subject/s are Selected!</div>');
						$('#alert-error-id').show(100).delay(2000).hide(100);
					}
					else{
						
						var sub ;
						if(output == "allSubjects"){
							sub = "selected_grade="+selected_grade+"&selected_teacher="+selected_teacher;
						}
						else{
							sub = "selected_grade="+selected_grade+"&selected_teacher="+selected_teacher;
						}
						$.ajax({
							url:'showStudentForAttendance.php',
							type:'post',
							data:sub,
						}).done( function(data){
							$('#modalData').html(data);
							$('#btn-ref').show();
							$('#btn-sel').hide();

						});
					}
				}
			}

		del_Array_Values();
	}

/**
 * get the attendance status of student
 **/
	function selectStatus(id, status){
		numrows = $('#numrows').val();

		for (var x = 0; x < numrows; x++){

			id_col_0[id] = (id)
			status_col_0[id] = (status)
			
			filtered_ids = $.grep(id_col_0, n => n == 0 || n);
			filtered_sts = $.grep(status_col_0, n => n == 0 || n);
		}
	}

/**
 * submit new data to database
 */
	function addAttendance(){
		numrows = $('#numrows').val(); 
		var selected_teacher = $('#facAtd').val();
		var selectElement = document.querySelector('#sAtd');
		var form_data;	
		var date = $('#attendance-date').val();
		var output = selectElement.options[selectElement.selectedIndex].value;

		if(date == ''){
			$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>Please select date first.</div>');
			$('#alert-error-id').show(100).delay(5000).hide(100);
			$('#btn-sel').show();
			$('#facAtd').val('');
			$('#sAtd').val('Subjects');
			$('#btn-ref').hide();
			$('#sGAtd').val('');
			$('#modalData').html('');
		}
		else{
			// alert(subjectArray)
			if(position == "Super Administrator"){
				var afacNo = $('#facAtd').val();
				var grade = $('#gradeLevel').val();

				if(filtered_ids !== undefined && filtered_sts !== undefined){
					id = filtered_ids;
					st = filtered_sts;
				}
				else{
					id = '';
					st = '';
				}
				
					if(output == "allSubjects"){
						form_data="ids="+id+"&status="+st+"&subject="+subject_Array+"&grade="+grade+"&num_rows="+numrows+"&facNo="+afacNo+"&date="+date;
					}		
					else{
						form_data="ids="+id+"&status="+st+"&subject="+$('#sAtd').val()+"&grade="+grade+"&num_rows="+numrows+"&facNo="+afacNo+"&date="+date;
					}			
								
					$.ajax({
						method:'post',
						data: form_data,
						url:'addAttendance.php'
					}).done(function(data){
						console.log(data);
						
						if(data === `idEmptyTeacher`){
							$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>Please Select an Instructor for the record.</div>');
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#btn-ref').hide();
							$('#sGAtd').val('');
							$('#modalData').html('');
							speakEmptyTeacherAttendance();
						}
						// if(data === `idError`){
						// 	$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>Student Attendance was already recorded on this subject.</div>');
						// 	$('#alert-error-id').show(100).delay(5000).hide(100);
						// 	$('#modalData').html('');
						// 	$('#btn-sel').show();
						// 	$('#facAtd').val('');
						// 	$('#sAtd').val('Subjects');
						// 	$('#sGAtd').val('');
						// 	$('#btn-ref').hide();
						// 	speakErrorAttendance();
						// }
						else if(data === `idEmptySubject`){
							$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>Please Select a Subject for the record.</div>');
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#btn-ref').hide();
							$('#sGAtd').val('');
							$('#modalData').html('');
							speakEmptySubjectAttendance();
						}
						else if(data === `idEmpty`){
							$('#alert-error-id').html("<div class='alert alert-danger alert-dismissible'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><i class='glyphicon glyphicon-info'></i>Some students was not Included in the Attendance. Please try again!</div>");
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#modalData').html('');
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#sGAtd').val('');
							$('#btn-ref').hide();
							speakEmptyAttendance();
						}
						else if(data === `invalidDate`){
							$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>You are not allowed to have an attendance today!</div>');
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#btn-ref').hide();
							$('#sGAtd').val('');
							$('#modalData').html('');
							speakEmptyTeacherAttendance();
						}
						else{					
							$('#addDpt').modal('hide');
							$('.modal-backdrop').hide();
							attendanceTab();
							$('#alertMessage').html(data);
							hideAlert();
							speakAttendance();
						}
					});
			}
			else if(position == "Administrator"){
				var afacNo = $('#faculty-id').val();
				var grade = "<?php echo $grade?>";
				if(filtered_ids !== undefined && filtered_sts !== undefined){
					id = filtered_ids;
					st = filtered_sts;
				}
				else{
					id = '';
					st = '';
				}
				
					if(output == "allSubjects"){
						form_data="ids="+id+"&status="+st+"&subject="+subjectArray+"&grade="+grade+"&num_rows="+numrows+"&facNo="+afacNo;
					}		
					else{
						form_data="ids="+id+"&status="+st+"&subject="+$('#sAtd').val()+"&grade="+grade+"&num_rows="+numrows+"&facNo="+afacNo;
					}			
								
					$.ajax({
						method:'post',
						data: form_data,
						url:'addAttendance.php'
					}).done(function(data){
						console.log(data);
						
						if(data === `idEmptyTeacher`){
							$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>Please Select an Instructor for the record.</div>');
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#btn-ref').hide();
							$('#sGAtd').val('');
							$('#modalData').html('');
							speakEmptyTeacherAttendance();
						}
						if(data === `idError`){
							$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>Student Attendance was already recorded on this subject.</div>');
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#modalData').html('');
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#sGAtd').val('');
							$('#btn-ref').hide();
							speakErrorAttendance();
						}
						else if(data === `idEmptySubject`){
							$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>Please Select a Subject for the record.</div>');
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#btn-ref').hide();
							$('#sGAtd').val('');
							$('#modalData').html('');
							speakEmptySubjectAttendance();
						}
						else if(data === `idEmpty`){
							$('#alert-error-id').html("<div class='alert alert-danger alert-dismissible'><a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a><i class='glyphicon glyphicon-info'></i>Some students was not Included in the Attendance. Please try again!</div>");
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#modalData').html('');
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#sGAtd').val('');
							$('#btn-ref').hide();
							speakEmptyAttendance();
						}
						else if(data === `invalidDate`){
							$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i>You are not allowed to have an attendance today!</div>');
							$('#alert-error-id').show(100).delay(5000).hide(100);
							$('#btn-sel').show();
							$('#facAtd').val('');
							$('#sAtd').val('Subjects');
							$('#btn-ref').hide();
							$('#sGAtd').val('');
							$('#modalData').html('');
							speakEmptyTeacherAttendance();
						}
						else{					
							$('#addDpt').modal('hide');
							$('.modal-backdrop').hide();
							attendanceTab();
							$('#alertMessage').html(data);
							hideAlert();
							speakAttendance();
						}
					});
			}			
		}

			
		
		// document.body.style.overflowY = 'scroll';
	}

	function del_Array_Values(){
			
		id=[];
		st=[];
		id_col_0=[];
		status_col_0=[];
		filtered_id = [];
		filtered_sts = [];
	}

	del_Array_Values();
</script>