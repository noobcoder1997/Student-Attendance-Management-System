<?php 
    include_once 'dbConfig.php';
	require_once('loginSession.php');
		$message = "";

		$row = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['row']));
		$user = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['user']));
		$name = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['name']));
		$pass0 = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['pass']));
		$position = stripcslashes(mysqli_real_escape_string($mysqli, "Administrator"));
		$stmt= mysqli_stmt_init($mysqli);
		
		if($user == '' || $name == '' || $pass0 == '' || $position == '' || $row == ''){
			$message = 'isEmpty';
		}
		else{
			mysqli_stmt_prepare($stmt, "SELECT * from users where username = ? AND password = ? AND row <> ?");
			mysqli_stmt_bind_param($stmt, 'sss', $user, $pass0, $row);
			mysqli_stmt_execute($stmt);
			$result = mysqli_stmt_get_result($stmt);
			if($r = mysqli_fetch_assoc($result)){
				$message = 'userError';
			}
			else{
				if(mysqli_stmt_prepare($stmt, "SELECT * FROM users WHERE row = ?")){				
					mysqli_stmt_bind_param($stmt, 's', $row);
					mysqli_stmt_execute($stmt);
					$result = mysqli_stmt_get_result($stmt);
					if($r = mysqli_fetch_assoc($result)){
						$pass1 = $r['password'];
						if($pass0 == $pass1){
							mysqli_stmt_prepare($stmt, "UPDATE users SET username = ?, name = ? WHERE row = ?");
							mysqli_stmt_bind_param($stmt, 'sss', $user, $name, $row);
							mysqli_stmt_execute($stmt);
							$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Administrator Successfully Updated!</div>';
						}
						else {
							$pass1 = md5($pass0);
							mysqli_stmt_prepare($stmt, "UPDATE users SET username = ?, name = ?, password = ? WHERE row = ?");
							mysqli_stmt_bind_param($stmt, 'ssss', $user, $name, $pass1, $row);
							mysqli_stmt_execute($stmt);
							$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Administrator Successfully Updated!</div>';
						}
					}
				}
			}
		}
		
		
	echo $message;
	mysqli_close($mysqli);
 ?>