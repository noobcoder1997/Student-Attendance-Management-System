<?php 
    include_once 'dbConfig.php';
	require_once('loginSession.php');
		$message = "";

		$id= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['id']));
		$fn = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['fn']));
		$mn = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['mn']));
		$ln = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['ln']));
		$sec = stripcslashes(mysqli_real_escape_string($mysqli, strtoupper($_POST['sec'])));
		$yr = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['yr']));
		$sex = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['sex']));
		$facNo = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['facNo']));
		$stmt= mysqli_stmt_init($mysqli);

		mysqli_stmt_prepare($stmt, "SELECT * from students where id = ? AND faculty = ? ");
		mysqli_stmt_bind_param($stmt, 'ss', $id, $facNo);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		if($r = mysqli_fetch_assoc($result)){
			$message = 'idError';
		}
		else if($id == null || $fn == null || $ln == null || $sec == null ||$yr == null || $facNo == null ){
			$message = 'isStudentEmpty';
		}
		else{
			if(mysqli_stmt_prepare($stmt, "INSERT INTO students(id,fn,mn,ln,section,year,sex,faculty) 
					VALUES (?,?,?,?,?,?,?,?)")) {
				mysqli_stmt_bind_param($stmt, 'ssssssss', $id, $fn, $mn, $ln, $sec, $yr, $sex, $facNo);
				mysqli_stmt_execute($stmt);
				$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Student Successfully Created!</div>';
			}else{
				$message = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Something went wrong</div>';
			}
		}
			
	echo $message;
	mysqli_close($mysqli);
 ?>