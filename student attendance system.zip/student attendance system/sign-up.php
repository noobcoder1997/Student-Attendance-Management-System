<?php
	include_once 'dbConfig.php';

	// if(isset($_SESSION['userStatus'])){
	// 	header('location: home.php');
	// }
?>
<?php
	// function setTimeout($function){
	// 	sleep((10));
    // 	$function();
	// }
	// $execFn = function() {
	// 	echo "<script>location.replace('logout.php')</script>";
	// }
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>SAMS - Sign up Page</title>
		<meta charset="utf-8">
		<link REL='shortcut icon' href="images/bethel.png">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script>
			(function hideMyURL() {
				var re = new RegExp(/^.*\//);
				window.history.pushState("object or string", "Title", re.exec(window.location.href));
			})();
		</script>
		<style>
			html{
				position: relative;
				min-height: 100%;
			}
			body{
				padding:0;
				margin: 0;
				background: #e8e8e8;
			}
			@font-face {
				font-family: myFont;
				src: url(fonts/poppins/Poppins-Regular.ttf);
			}
			h3{
				color: #5a8dee;
				font-family: myFont;
			}
			.login-form{
				margin-top:20px;
				font-family: myFont;
			}
			.box{
				display: flex;
				flex-flow: row wrap;
				margin-top: 50px;
				box-shadow: 0 0 15px #A9A9A9;
				border-radius: 10px;
			}
			.login-tab{
				height: auto;
				border-radius: 10px 0px 0px 10px;
				color: #002D62;
				background-color: #fff;
				overflow: hidden;
				padding: 20px;
			}
			@media only screen and (max-width: 768px) {
				.login-tab{
					border-radius: 10px 10px 0px 0px;
				}
				.box{
					margin: 10px 2px 2px 2px;
				}
			}
			button{
				margin-top: 15px;
			}
			.btn{
				border-radius: 20px;
			}
			input[type='text'],input[type='password']{
				border-radius: 20px;
			}
		</style>
	</head>
	<body>
		<div class="container-fluid">
			<div class="col-sm-12">
				<div class="row">
					<div class="col-sm-2"></div>
					<div class="col-sm-8">
						<div class="row box">
							<div class="col-sm-12 login-tab">
								<center>
									<h3>STUDENT ATTENDANCE MANAGEMENT SYSTEM (SAMS)</h3>
								</center>
								<div class="row ">
									<div class="col-sm-12">
										<?php
											if(isset($_SESSION['message'])){
											echo `<script>window.scrollTo(0,0);</script>`;
										?>
										<div class="alert alert-warning">
											<p id="message" style="display:block">
										<?php	
											echo $_SESSION['message'];
											unset($_SESSION['message']);
											// setTimeout($execFn);
										?>
											</p>
											<p id="redirect" style="display:none"></p>
										</div>
										<input type="hidden" id="alert-message" value="success">
										<?php
											}
										?>
									</div> 
									<div class="col-sm-4">
									<form action="sign.up.upload.image.php" method="POST" role="form" enctype="multipart/form-data">
										<div class="form-group">
											<label for="user">First Name:</label>
											<input type="text" class="form-control input-lg" name="fnim" placeholder="First Name" required>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="form-group">
											<label for="user">Middle Name: (Optional)</label>
											<input type="text" class="form-control input-lg" name="mnim" placeholder="Middle Name" required>
										</div>
									</div>
									<div class="col-sm-4">
										<div class="form-group">
											<label for="user">Last Name:</label>
											<input type="text" class="form-control input-lg" name="lnim" placeholder="Last Name" required>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-4">
										<div class="form-group">
											<label for="user">Username:</label>
											<input type="text" class="form-control input-lg" name="user" placeholder="Username" required>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<label for="pass">Password:</label>
											<input type="password" class="form-control input-lg" name="pass0" id="pass0" placeholder="Password" required>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<label for="pass">Confirm Password:</label>
											<input type="password" class="form-control input-lg" name="pass1" id="pass1" placeholder="Confirm Password" required>
											<small id="alert-password"></small>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
									<div class="form-group">
										<label for="user">Profile Picture:</label>
											<center>
												<label for='image' style="cursor: pointer;">
												<img id="img_content" src="images/default.jpg" class="img-circle" alt="Profile Photo" height="130px;" width="130px;" style="object-fit:cover">
											<br>
												Browse Pictures
												<span class="glyphicon glyphicon-camera" style="color: #A9A9A9;"></span> 
												</label>
												<input type="file" name="image" id="image" accept="image/*" style="display: none;">
											</center>
										</div>
										<div class="modal-footer">
									</div>
								</div>
									<div class="col-sm-12">
										<button type="submit" class="btn btn-primary btn-lg btn-block">
											<span class="glyphicon glyphicon-log-in"></span> Sign up
										</button>
									</div>
									</form>
									<br>
									<center><a class="center" onclick="location.replace('index.php')">I have an Account, Sign in.</a></center>
								</div>
								</div>
								<br>
								<!-- </div>
								<div class="col-sm-4">

								</div>
								<div class="col-sm-12"> -->
									<!-- <div class="checkbox">
									  <label><input type="checkbox" onclick="showPass();"> Show Password</label>
									</div> -->
									
									<!-- <button type="button" class="btn btn-danger btn-lg btn-block" onclick="forgotPass();"style="margin-top: 10px;">
										<span class="glyphicon glyphicon-lock"></span> Forgot Password
									</button> -->
									
							</div>
							<!-- <div class="col-sm-7"> -->
								<!-- <center> -->
									<!-- attendance matters 2.png -->
									<!-- Every-day-counts-1024x505.png -->
									<!-- <img src="images/Every-day-counts-1024x505.png" alt="Login-logo" style="width:100%; margin-top:12rem;"> -->
								<!-- </center> -->
							</div>
						</div>
					</div>
					<!-- <div class="col-sm-12"> -->
						
					<!-- </div> -->
				</div>
			</div>
		</div>
	</body>
	<script>
		var passInput0 = document.getElementById("pass0");
		var passInput1 = document.getElementById("pass1");
		var alertpass = document.getElementById("alert-password");
		var pass;

		passInput1.onkeyup = function(e){
			if(passInput1.value != passInput0.value){
				$('#alert-password').html('Password did not match!');
				alertpass.style.color="red";
			}
			if(passInput1.value == "" ||  passInput0.value == ""){
				$('#alert-password').html('');
			}
			else if(passInput1.value == passInput0.value){
				$('#alert-password').html('Password match!');
				alertpass.style.color="blue";
				pass = passInput1.value = passInput1.value;
			}
		}
		passInput0.onkeyup = function(e){
			if(passInput1.value != passInput0.value){
				$('#alert-password').html('Password did not match!');
				alertpass.style.color="red";
			}
			if(passInput1.value == "" ||  passInput0.value == ""){
				$('#alert-password').html('');
			}
			else if(passInput1.value != "" && passInput1.value == passInput0.value){
				$('#alert-password').html('Password match!');
				alertpass.style.color="blue";
				pass = passInput1.value = passInput1.value;
			}
		}

		window.addEventListener('load', function () {
			document.querySelector('input[type="file"]').addEventListener('change', function () {
				if (this.files && this.files[0]) {
				var img = document.getElementById('img_content');
				img.onload = () => {
					URL.revokeObjectURL(img.src);
				}
				img.src = URL.createObjectURL(this.files[0]);
				}
			});
		});


		if($('#alert-message').val()=='success'){
			var timeleft = 4;
			var i=1;

			var downloadTimer = setInterval(function(){

			const divtag = document.getElementById("message");
			divtag.style.display='none';

			const ptag = document.getElementById("redirect")
			ptag.style.display='block';

				if(timeleft <= i){
					clearInterval(downloadTimer);
					location.replace('index.php')
				}
				document.getElementById("redirect").innerHTML = 'Redirecting in... <b>'+(timeleft - i)+'</b>';
				timeleft -= 1;
			}, 1000);
		}
		
	</script>
</html>