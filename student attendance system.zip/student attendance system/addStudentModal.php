<div class="modal fade" id="addStd" role="dialog"  data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-plus"></span> Add a Student</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="idStud">LRN<b style="color:red">*</b></label>
					<input class="form-control" id="idStud" type="text" placeholder="LRN">
				</div>
				<div class="form-group">
					<label for="fnStud">First Name<b style="color:red">*</b></label>
					<input class="form-control" id="fnStud" type="text" placeholder="First Name">
				</div>
				<div class="form-group">
					<label for="mnStud">Middle Name</label>
					<input class="form-control" id="mnStud" type="text" placeholder="Middle Name">
				</div>
				<div class="form-group">
					<label for="lnStud">Last Name<b style="color:red">*</b></label>
					<input class="form-control" id="lnStud" type="text" placeholder="Last Name">
				</div>
				<div class="form-group">
					<label for="dob">Date of Birth<b style="color:red">*</b></label>
					<input class="form-control" id="dob" type="date" placeholder="Date of birth">
				</div>
				<div class="form-group">
					<label for="sexStud">Sex</label>
					<select class="form-control" id="sexStud" type="text" placeholder="Year">
						<option selected disabled>Sex</option>
						<option value='0' >Male</option>
						<option value='1' >Female</option>
					</select>
				</div>
				<div class="form-group">
					<label for="relStud">Religion</label>
					<input class="form-control" id="relStud" type="text" placeholder="Religion">
				</div>
				<div class="form-group">
					<label for="hStud">House #/ Street/ Sitio/ Purok</label>
					<input class="form-control" id="hStud" type="text" placeholder="House #/ Street/ Sitio/ Purok">
				</div>
				<div class="form-group">
					<label for="bStud">Barangay</label>
					<input class="form-control" id="bStud" type="text" placeholder="Barangay">
				</div>
				<div class="form-group">
					<label for="munStud">Municipality</label>
					<input class="form-control" id="munStud" type="text" placeholder="Municipality">
				</div>
				<div class="form-group">
					<label for="provStud">Province</label>
					<input class="form-control" id="provStud" type="text" placeholder="Province">
				</div>
				<div class="form-group">
					<label for="relStud">Father's Name</label>
					<input class="form-control" id="fLStud" type="text" placeholder="Last Name">
					<br>
					<input class="form-control" id="fMStud" type="text" placeholder="Middle Name">
					<br>
					<input class="form-control" id="fFStud" type="text" placeholder="First Name">
				</div>
				<div class="form-group">
					<label for="relStud">Mother's Maiden Name</label>
					<input class="form-control" id="mLStud" type="text" placeholder="Last Name">
					<br>
					<input class="form-control" id="mMStud" type="text" placeholder="Middle Name">
					<br>
					<input class="form-control" id="mFStud" type="text" placeholder="First Name">
				</div>
				<div class="form-group">
					<label for="relStud">Guardian </label>
					<input class="form-control" id="gLStud" type="text" placeholder="Name">
					<br>
					<input class="form-control" id="gMStud" type="text" placeholder="Relationship">
				</div>
				<div class="form-group">
					<label for="relStud">Contact Number </label>
					<input class="form-control" id="gLStud" type="text" placeholder="Contact Number of Parent or Guardian">
				</div>
				<div class="form-group">
					<label for="yrStud">Grade</label>
					<select class="form-control" id="yrStud" type="text" placeholder="Year">
						<option selected disabled>Grade Level</option>
						<?php 
							$resGrde0 =mysqli_query($mysqli, "SELECT * from grades");
							while ($rgrde0 = mysqli_fetch_assoc($resGrde0)){
								echo "<option value=$rgrde0[grade]>Grade $rgrde0[grade]</option>";
							}
						?>
					</select>
				</div>
				<div class="form-group">
					<label for="secStud">Section<b style="color:red">*</b></label>
					<input class="form-control" id="secStud" type="text" placeholder="Section">
				</div>
				<?php
				if($position == "Super Administrator"){
				?>
					<div class="form-group">
						<label for="facStud">Instructor<b style="color:red">*</b></label>
						<select class="form-control" id="facStud" type="text" placeholder="Instructor">
							<option value='' selected disabled>Instructor</option>
							<?php
								$facRes = mysqli_query($mysqli, "SELECT * FROM users WHERE position = 'Administrator' ");
								while ($r = mysqli_fetch_assoc($facRes)) {
									echo "<option value=$r[row]>$r[name]</option>	";
								}
							?>
						</select>
					</div>
				<?php 
				}
				?>
				<script>				
					$(document).ready(function() {
						$("#addStd").on("hide.bs.modal", function() {
							$("#addStd input").val('');
						});
					});
				</script>
				<span id="alertStud"></span>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary btn-block" onclick="addStudent();"><span class="glyphicon glyphicon-plus"></span> Add this Student</button>
			</div>
		</div>
	</div>
</div>