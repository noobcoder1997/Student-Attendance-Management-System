<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];
?>
<div class="container">
	<h3>Subjects</h3>
	<div class="row">
		<div class="col-md-3">
			<button class="btn btn-primary" data-toggle="modal" data-target="#AddSubModal"><span class="glyphicon glyphicon-plus">&nbsp;</span>Create Subject</button>
		</div>
	</div>
<br/>
<div class="row">
		<div class="col-md-12">
			<div class="table-responsive">
			<table id="datatableSub" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th></th>
							<th>Subject</th>
							<th>Description</th>
							<th>Level</th>
							<?php 
								if( $position == "Super Administrator" ) {
									echo "<th>Teacher</th>";
								}
							?>
							<th><center>Edit</center></th>
							<th><center>Delete</center></th>
						</tr>
					</thead>
					<tfoot>
						<tr>
						<th></th>
							<th>Subject</th>
							<th>Description</th>
							<th>Level</th>
							<?php 
								if( $position == "Super Administrator" ) {
									echo "<th>Teacher</th>";
								}
							?>
							<th><center>Edit</center></th>
							<th><center>Delete</center></th>
						</tr>
					</tfoot>
					<tbody>
						<?php
						$_subjects_ ='';
						if($position == "Administrator") {
							$_subjects_ =mysqli_query($mysqli, "SELECT * from subjects WHERE faculty = '$row' ORDER BY grade ASC ");
						}if($position == "Super Administrator")  {
							$_subjects_ =mysqli_query($mysqli, "SELECT * from subjects");
						}
							while ($_subject_ = mysqli_fetch_assoc($_subjects_)){
								?>
										<td> <?php echo $_subject_["row"]; ?></td>
										<td> <?php echo $_subject_['subject']; ?></td>
										<td> <?php echo $_subject_['description']; ?></td>
										<td> <?php echo $_subject_['grade']; ?></td>
								<?php
									if( $position == "Super Administrator" ) {
										$teacher  =  mysqli_query($mysqli, "SELECT * FROM users WHERE row = $_subject_[faculty] ");
										$rteacher = mysqli_fetch_assoc($teacher);
								?>		
										<td><?php echo $rteacher['name']; ?></td>
								<?php
									}
								echo 	"<td>
											<center>
												<button class='btn btn-warning btn-xs' data-toggle='modal' data-target='#editSubModal".$_subject_['row']."'>
													<span class='glyphicon glyphicon-pencil'></span> Edit
												</button>
											</center>
										</td>
										<td>
											<center>
												<button class='btn btn-danger btn-xs' data-toggle='modal' data-target='#deleteSubModal".$_subject_['row']."'>
													<span class='glyphicon glyphicon-remove'></span> Delete
												</button>
											</center>
										</td>
									";
						?>
									</tr>
						<?php include 'deleteSubjectModal.php'; ?>
						<?php include 'updateSubjectModal.php'; ?>
						<?php				 
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php include 'addSubjectModal.php'; ?>
<script>
	$('#datatableSub').dataTable();
	$("[data-toggle=tooltip]").tooltip();
</script>
<script type="text/javascript">

	function addSubject(){
		var position = $('#position-id').val();
		var sTitle = $('#sTitle').val();
		var sDesc = $('#sDesc').val();
		var sLevel = $('#sLevel').val();
		var sFacNo = "";

		if(position == "Super Administrator"){sFacNo = $('#sFac').val();}else {sFacNo = $('#faculty-id').val();}

		var sData="sTitle="+sTitle+"&sDesc="+sDesc+"&sLevel="+sLevel+"&facNo="+sFacNo;
		$.ajax({
			method:"post",
			url:"addSubject.php",
			data: sData,
		}).done(function(data){
			// console.log(data);
			if(data == "subjectError"){
				$('#alertSubject').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Subject was already listed!</div>');
			}
			else if(data == "subjectEmpty"){
				$('#alertSubject').html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please fill all required empty field/s!</div>');
			}
			else{
				$('#AddSubModal').modal('hide');
				$('.modal-backdrop').hide();
				subjectTab();
				$('#alertMessage').html(data);
				hideAlert();
			}
		});
		document.body.style.overflowY = 'scroll';
	}

	function editSubject(rows){
		var row = rows;
		var sTitle = $('#sTitle'+row).val();
		var sDesc = $('#sDesc'+row).val();
		var sLevel = $('#sLevel'+row).val();
		
		var sData="sTitle="+sTitle+"&sDesc="+sDesc+"&sLevel="+sLevel+"&row="+row;
		$.ajax({
			method:"post",
			url:"updateSubject.php",
			data: sData,
		}).done(function(data){
			// console.log(data);
			if(data == `subjectError`){
				$('#EalertSubject'+row).html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Subject was already listed!</div>');
			}
			else if(data == `sEmpty`){
				$('#EalertSubject'+row).html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please fill required empty field/s!</div>');
			}
			else{
				$('#editSubModal'+row).modal('hide');
				$('.modal-backdrop').hide();
				subjectTab();
				$('#alertMessage').html(data);
				hideAlert();
			}
		});
		document.body.style.overflowY = 'scroll';		
	}

	function deleteSubject(rows){
		var r = rows;
		var row = "row="+r;
		$.ajax({
			url:'deleteSubject.php',
			data: row,
			method:'post',
		}).done(function(data){
			// console.log(data);
			$('#deleteSubModal'+rows).modal('hide');
			$('.modal-backdrop').hide();
			subjectTab();
			$('#alertMessage').html(data);
			hideAlert();
		});
		document.body.style.overflowY = 'scroll';
	}

</script>