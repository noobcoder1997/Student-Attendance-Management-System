<?php
    include_once 'dbConfig.php';
    require_once('loginSession.php');
    require 'vendor/autoload.php';

    $message = "";

    use PhpOffice\PhpSpreadsheet\Spreadsheet;
    use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

    $row = $_POST['faculty'];
    $subject = $_POST['subject'];
    $date = $_POST['date'];
    $grade = $_POST['grade'];
    $dateToday = date('M-d-Y');
    $status;
    $query0;

    if ($subject == null || $date == null || $date == null) { 
        $query0 = mysqli_query($mysqli, "SELECT * from attendance WHERE faculty = '$row' AND attendance_date = '$dateToday' ");
    }
    else{
        $query0 = mysqli_query($mysqli, "SELECT * from attendance WHERE faculty = '$row' AND attendance_date = '$date' AND subject = '$subject' AND grade = '$grade' ");
    }
    if (isset($_POST['submit'])) {
        if (mysqli_num_rows($query0) > 0) {
            $spreadsheet = new Spreadsheet();
            $activeWorksheet = $spreadsheet->getActiveSheet();

            $activeWorksheet->setCellValue('A1', 'ID');
            $activeWorksheet->setCellValue('B1', 'Student');
            $activeWorksheet->setCellValue('C1', 'Attendance Status');
            $activeWorksheet->setCellValue('D1', 'Date');
            $activeWorksheet->setCellValue('E1', 'Grade');
            $activeWorksheet->setCellValue('F1', 'Subject');

            $count = "2";
            foreach ($query0 as $q) {
                $query1 = mysqli_query($mysqli, "SELECT * from students WHERE faculty = '$row' AND id = $q[studentId] ORDER BY ln");
                $q1 = mysqli_fetch_assoc($query1);
                $query2 = mysqli_query($mysqli, "SELECT * from  subjects WHERE faculty = '$row' AND row = $q[subject] ");
                $q2 = mysqli_fetch_assoc($query2);
                if ($q['status'] == '0') {
                    $status = 'Present';
                } else if ($q['status'] == '1') {
                    $status = 'Absent';
                } else if ($q['status'] == '2') {
                    $status = 'Excused';
                }
                $activeWorksheet->setCellValue('A' . $count, $q1['id']);
                $activeWorksheet->setCellValue('B' . $count, $q1['ln'] . ", " . $q1['fn'] . " " . $q1['mn']);
                $activeWorksheet->setCellValue('C' . $count, $status);
                $activeWorksheet->setCellValue('D' . $count, $q['attendance_date']);
                $activeWorksheet->setCellValue('E' . $count, "Grade " . $q['grade']);
                $activeWorksheet->setCellValue('F' . $count, $q2['subject']);
                $count++;
            }

            $writer = new Xlsx($spreadsheet);
            $fileName = "attendance" . time() . ".xlsx";
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename=' . urlencode($fileName));
            $writer->save('php://output');

            echo `$('#alertMessage').html(<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Spreadsheet was created successfully!</div>);`;
        }
        else{
            echo "<script> history.go(-1)</script>";
            exit();
        }
    }


echo $message;
mysqli_close($mysqli);
