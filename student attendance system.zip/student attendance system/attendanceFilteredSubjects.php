<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
?>
<script>  
	$('#datatable-selected-attendance').dataTable();
	$("[data-toggle=tooltip]").tooltip();
</script>
	<div class="col-md-12">
		<div class="table-responsive">
		<table id="datatable-selected-attendance" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th></th>
						<th>Student's Name</th>
						<th>Grade</th>
						<th>Subject</th>
						<th>Status</th>
						<th><center>Edit</center></th>
						<th><center>Delete</center></th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th></th>
						<th>Student's Name</th>
						<th>Grade</th>
						<th>Subject</th>
						<th>Status</th>
						<th><center>Edit</center></th>
						<th><center>Delete</center></th>
					</tr>
				</tfoot>
				<tbody>
					<?php
						$filtered_date = $_POST['date'];
						// $filtered_grade = $_POST['grade'];
						$filtered_subject= '';
						$filtered_teacher= '';
						$filtered_subject = $_POST['subject'];
						$filtered_teacher = $_POST['facId'];
						$attResult = mysqli_query($mysqli, "SELECT * from attendance WHERE attendance_date = '$filtered_date' AND subject = '$filtered_subject' AND faculty = '$filtered_teacher' ");
						while ($r = mysqli_fetch_assoc($attResult)){
							$r['subject'];
							$sbjctResult = mysqli_query($mysqli, "SELECT * from subjects WHERE row = '".$r['subject']."' ");
							$sbjct = mysqli_fetch_assoc($sbjctResult);
							$stdtResult = mysqli_query($mysqli, "SELECT * from students WHERE id = '".$r['studentId']."' ");
							$s = mysqli_fetch_assoc($stdtResult);	
							$mn = $s['mn'];
							if(isset($s['mn'])){
								$mn =$s['mn'];
							}
							else{
								$mn='';
							}
							if(isset($sbjct['subject']) == null){
								echo "<tr>
									<td> $s[id] </td>
									<td> <b>$s[ln]</b>, $s[fn] ".strtoupper($mn[0]).".</td>
									<td> Grade $r[grade] </td>
									<td> --No Subject-- </td>";	
							}
							if($mn == ''){
								echo "<tr>
									<td> $s[id] </td>
									<td> <b>$s[ln]</b>, $s[fn] </td>
									<td> Grade $r[grade] </td>
									<td> $sbjct[subject] </td>";	
							}
							else{
									echo "<tr>
											<td> $s[id] </td>
											<td> <b>$s[ln]</b>, $s[fn] ".strtoupper($mn[0]).".</td>
											<td> Grade $r[grade] </td>
											<td> $sbjct[subject] </td>";
								}
									if($r['status'] == 0){
										echo "<td> <a class='btn btn-primary btn-xs btn-block btn-status'>Present</a> </td>";
									}if($r['status'] == 1){
										echo "<td> <a class='btn btn-danger btn-xs btn-block btn-status'>Absent</a> </td>";
									}if($r['status'] == 2){
										echo "<td> <a class='btn btn-warning btn-xs btn-block btn-status'>Excused</a> </td>";
									}
							echo 	"<td>
										<center>
											<button class='btn btn-warning btn-xs' data-toggle='modal' data-target='#editStAttendance".$r['row']."'>
												<span class='glyphicon glyphicon-pencil'></span> Edit
											</button>
										</center>
									</td>
									<td>
										<center>
											<button class='btn btn-danger btn-xs' data-toggle='modal' data-target='#deltStAttendance".$r['row']."'>
												<span class='glyphicon glyphicon-trash'></span> Delete
											</button>
										</center>
									</td>
								</tr>
								";
					?>
					<?php include 'deleteAttendanceModal.php'; ?>
					<?php include 'updateAttendanceModal.php'; ?>
					<?php				 
						}
					?>
				</tbody>
			</table>
		</div>
	</div>