<script>  
  $('#datatable-daily-attendance').dataTable();
  $("[data-toggle=tooltip]").tooltip();
</script>

<?php
  include_once 'dbConfig.php';
  require_once('loginSession.php');
  $row = $_SESSION['row'];
  $position = $_SESSION['position'];

  $grade= $_POST['selected_grade'];//grade ni
  $teacher= $_POST['selected_teacher'];//teacher ni
  $student_query="";
  $subject_query="";
  
  if ($position == "Super Administrator"){
    $student_query= mysqli_query($mysqli, "SELECT * FROM students WHERE year  = '$grade' AND faculty = '$teacher' ORDER BY ln ASC");
  }
  if ($position == "Administrator"){
    $student_query= mysqli_query($mysqli, "SELECT * FROM students WHERE year  = '$grade' AND faculty = '$row' ORDER BY ln ASC");
  }
?>
<div class=" col-md-12">
    <div class="table-responsive">
        <table id="datatable-daily-attendance" class="table table-striped table-bordered">
          <thead>
            <th></th>
            <th>Name</th>
            <th>Grade</th>
            <th>Present</th>
            <th>Absent</th>
            <th>Excused</th>
          </thead>
          <tbody>
            <?php
              while($result_query=mysqli_fetch_assoc($student_query)){
                $i=0;
                $n=mysqli_num_rows($student_query);
              
            ?>
            <tr>
              <td><?php echo $result_query['id']?></td>
              <td><b><?php echo $result_query['ln']."</b>, ". $result_query['fn']." ".$result_query['mn']?></td>
              <td><?php echo $result_query['year']?></td>
              <td>
                <div class='radio-centered'>
                  <input type='radio' class='rt' onclick="selectStatus(<?php echo $result_query['id']?>, 0, 1);" name='radio<?php echo $result_query['row']?>' id='rt<?php echo $result_query['id']?>' value=''>
                </div>
              </td>
              <td>
                <div class='radio-centered'>
                  <input type='radio' class='rt' onclick="selectStatus(<?php echo $result_query['id']?>, 1, 2);" name='radio<?php echo $result_query['row']?>' id='rt<?php echo $result_query['id']?>' value=''>
                </div>
              </td>
              <td>
                <div class='radio-centered'>
                  <input type='radio' class='rt' onclick="selectStatus(<?php echo $result_query['id']?>, 2, 3);" name='radio<?php echo $result_query['row']?>' id='rt<?php echo $result_query['id']?>' value=''>
                </div>
              </td>
            </tr>                
            <?php
              $i++;
              }
            ?>
          </tbody>
          <tfoot>
            <th></th>
            <th>Name</th>
            <th>Grade</th>
            <th>Present</th>
            <th>Absent</th>
            <th>Excused</th>
          </tfoot>
        </table>
        <input id="numrows" value="<?php echo $n; ?>" type="hidden">
    </div>
</div>
<div class='col-md-12'>
    <input type="button" id="btn-submit" value="SUBMIT ATTENDANCE" onclick="addAttendance()" class="btn btn-primary btn-block">
</div>

