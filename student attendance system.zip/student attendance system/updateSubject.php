<?php 
    include_once 'dbConfig.php';
	require_once('loginSession.php');
		$message = "";

		$r = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['row']));
		$s = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['sTitle']));
		$d = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['sDesc']));
		$l = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['sLevel']));
		$stmt = mysqli_stmt_init($mysqli);
		
		if($r == null || $s == null || $d == null || $l == 'null'){
			$message = "sEmpty";
		}
		else{
			mysqli_stmt_prepare($stmt, "SELECT * FROM subjects WHERE subject = ? AND description = ? AND grade = ?");
			mysqli_stmt_bind_param($stmt, 'sss', $s, $d, $l);
			mysqli_stmt_execute($stmt);
			$g = mysqli_stmt_get_result($stmt);
			if($r1 = mysqli_fetch_assoc($g)){
				$message = "subjectError" ;
			}
			else {
				if(mysqli_stmt_prepare($stmt, "UPDATE subjects SET subject = ?, description = ?, grade = ? WHERE row = ?")){
					mysqli_stmt_bind_param($stmt, 'ssss', $s, $d, $l, $r);
					mysqli_stmt_execute($stmt);
					$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Subject Successfully Updated!</div>';
				}
				else{
					$message = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Something went wrong!</div>';
				}
			}
		}
		
		
	echo $message;
	mysqli_close($mysqli);
 ?>
