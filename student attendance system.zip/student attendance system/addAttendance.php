<?php 
    include_once 'dbConfig.php';
	require_once('loginSession.php');
		$message = "";
		$speak = "";

		

		$num_rows= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['num_rows']));//counted rows
		$date= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['date'])); //date submitted
		$grade= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['grade']));//grade status
		$subject= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['subject'])); //subject status
		$faculty= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['facNo'])); //subject status
  		$imploded_ids= stripcslashes(mysqli_real_escape_string($mysqli, implode(',',[$_POST['ids']]))); //student Ids
		$imploded_status= stripcslashes(mysqli_real_escape_string($mysqli, implode(',',[$_POST['status']])));//student status

		$exploded_ids= explode(',',$imploded_ids);
		$exploded_status= explode(',',$imploded_status);
		$subject =  explode(',',$subject);
		$stmt= mysqli_stmt_init($mysqli);

		$time_input = strtotime($date);
		$d = getDate($time_input);
		$wkday = $d['weekday'];
		$mDay = $d['mday'];
		$Month = $d['month'];
		$year = $d['year'];

		// if($wkday == "Saturday" OR $wkday == "Sunday"){
		// 	$message = 'invalidDate';
		// }
		// else{
			foreach($subject as $s){
				for($x=0;$x<$num_rows;$x++){

					$exploded_ids[$x];
					$exploded_status[$x];

					if(($exploded_ids === 0 || $exploded_status === 0 ) || 
						$exploded_ids[$x] == null || $exploded_status[$x] == null || 
						(count($exploded_ids) < $num_rows || count($exploded_status) < $num_rows)){
						$message = 'idEmpty';
						break;
					}
					else if($faculty == null || $faculty == ''){
						$message = 'idEmptyTeacher';
						break;
					}
					else if($s == null || $s == ''){
						$message = 'idEmptySubject';
						break;
					}
					else{
						mysqli_stmt_prepare($stmt, "SELECT * FROM attendance WHERE studentId = ? AND subject = ? AND attendance_date = ? AND faculty = ?");
						mysqli_stmt_bind_param($stmt, "ssss", $exploded_ids[$x], $s, $date, $faculty);
						mysqli_stmt_execute($stmt);
						$result = mysqli_stmt_get_result($stmt);
						if($r = mysqli_fetch_assoc($result)){
							// $message = 'idError';
							mysqli_stmt_prepare($stmt, "UPDATE attendance SET status = ? WHERE row = ? ");
							mysqli_stmt_bind_param($stmt, 'ss', $exploded_status[$x], $r['row']);
							mysqli_stmt_execute($stmt);
							$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Student was Added Successfully!</div>';

						}else{
							if( mysqli_stmt_prepare($stmt, "INSERT INTO attendance (studentId, status, attendance_date, grade, subject, faculty) VALUES (?, ?, ?, ?, ?, ?)")) {
								mysqli_stmt_bind_param($stmt, 'ssssss', $exploded_ids[$x], $exploded_status[$x], $date, $grade, $s, $faculty);
								mysqli_stmt_execute($stmt);
								$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Student was Added Successfully!</div>';
								$speak = '<script>speakAttendance();</script>';

							}else{
								$message = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Something went wrong! Please try again.</div>';
							}
						}
					}
				}	
			}
		// }
	echo $message;
	// echo $speak;
	mysqli_close($mysqli);
 ?>