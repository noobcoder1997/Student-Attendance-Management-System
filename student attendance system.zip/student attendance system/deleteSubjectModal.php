<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];
?>
<div class="modal fade" id="deleteSubModal<?php echo $_subject_['row']?>" role="dialog" data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-remove">&nbsp;</span>Delete Student Information</h4>
			</div>
			<div class="modal-body">
				<?php
					if ($position == "Super Administrator"){ 
				?> 
				<div class="alert alert-danger">
					<span class="glyphicon glyphicon-warning-sign"></span> 
					Are you sure you want to delete this Subject?
				</div>
				<?php
					}
					if ($position == "Administrator"){
				?>
				<div class="alert alert-danger">
					<span class="glyphicon glyphicon-warning-sign"></span> 
					You are not allowed to delete this Subject?
				</div>
				<?php 
					}
				?>
			</div>
			<div class="modal-footer">
				<?php
					if ($position == "Super Administrator"){ 
				?> 
				<button type="button" class="btn btn-warning" onclick="deleteSubject('<?php echo $_subject_['row']?>');"><span class="glyphicon glyphicon-remove"></span> Continue</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
				<?php 
					}
					if ($position == "Administrator"){	
				?>
				<button type="button" class="btn btn-default" data-dismiss="modal">OK</button>
				<?php 
					}
				?>
			</div>
		</div>
	</div>
</div>