<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];
?>
<style>
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}
</style>
<?php

$array_subjects;
$array_subjects;
$grade;
$arrarSubjects=array();

?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<H3>Attendance Record</H3>
		</div>
		<div class="col-md-12">
			<label>Filter Attendance Record</label>
		</div>
		<div class="col-md-12">
			<select class="form-control" id="sel-date" onchange="" style="margin-bottom: 10px;">
				<option value=''>Select Date</option>
				<?php
					$dateQry = '';
					if($position == "Administrator"){ $dateQry = mysqli_query($mysqli, "SELECT * FROM attendance WHERE faculty = '$row' GROUP BY attendance_date");}
					else{ $dateQry = mysqli_query($mysqli, "SELECT * FROM attendance GROUP BY attendance_date"); }
					while($resQry = mysqli_fetch_assoc($dateQry)){
						echo "<option value=$resQry[attendance_date]>$resQry[attendance_date]</option>";
					}
				?>
			</select>	
		</div>
		<div class="col-md-12" >
			<select class="form-control" id="sel-grade" onchange="" style="margin-bottom: 10px;">
				<option value=''>Select Grade</option>
				<?php
					$grdQry = '';
					if($position == "Administrator") { $grdQry = mysqli_query($mysqli, "SELECT * FROM attendance WHERE faculty = '$row' GROUP BY grade"); }
					else { $grdQry = mysqli_query($mysqli, "SELECT * FROM attendance GROUP BY grade"); }
					while($resQry = mysqli_fetch_assoc($grdQry)){
						echo "<option value=$resQry[grade]>Grade $resQry[grade]</option>";
					}
				?>
			</select>
		</div>
		<div class="col-md-12">
			<select class="form-control" id="sel-subject" onchange="" style="margin-bottom: 10px;">
				<option value=''>Select Subject</option>
				<?php
					$atQry = '';
					if($position == "Administrator") {$atQry = mysqli_query($mysqli, "SELECT * FROM attendance WHERE faculty = '$row' "); }
					else{ $atQry = mysqli_query($mysqli, "SELECT * FROM attendance "); }
	
					$sbQry = mysqli_query($mysqli, "SELECT * FROM subjects GROUP BY subject");
					while($resSBQry = mysqli_fetch_assoc($sbQry)){
						$resQry = mysqli_fetch_assoc($atQry);
						array_push($arrarSubjects,$resSBQry['row']);
						echo "<option value=$resSBQry[row]>$resSBQry[subject]</option>";
					}
				?>
				<option value="allSubjects">All Subjects</option>
			</select>
		</div>
		<?php 
			if( $position == "Super Administrator" ) {
			?>
				<div class="col-md-12">
					<select class="form-control" id="sel-faculty" onchange="" style="margin-bottom: 10px;">
						<option value=''>Select Teacher</option>
						<?php
							$tQry = mysqli_query($mysqli, "SELECT * FROM attendance GROUP BY faculty "); 
							while($resQry = mysqli_fetch_assoc($tQry)){
								$sTQry = mysqli_query($mysqli, "SELECT * FROM users WHERE row = '$resQry[faculty]' ");
								$resTQry = mysqli_fetch_assoc($sTQry);
								echo "<option value=$resTQry[row]>$resTQry[name]</option>";
							}
						?>
					</select>
				</div>
			<?php
			}
		?>
		<div class="col-md-12">
			<button class='btn btn-info form-control' onclick="selectDate()"><span class="glyphicon glyphicon-new-window"></span> Show Attendance</button>
		</div>
	</div>
	<?php
	if($position == 'Administrator'){
		$subjectQuery = mysqli_query($mysqli, "SELECT * FROM subjects WHERE faculty = '$row' ");
		while($result = mysqli_fetch_assoc($subjectQuery)){	
			?>
				<div class="col-sm-3" style="margin-top: 10px;">
					<input type="radio" name="radio-subject" id="radio-<?php echo $result['row'];?>-0" onclick="radioCheckedRecord('<?php echo $result['row'];?>')" style="height: 10px; width: 10px; padding: 1px; margin-top: 5px;">
					<label for="radio-<?php echo $result['row'];?>-0" style="margin-right:10px">&nbsp;&nbsp;<?php echo $result['subject'];?></label>
				</div>
			<?php
		}
	}
	else if($position == 'Super Administrator'){
		$subjectQuery = mysqli_query($mysqli, "SELECT * FROM subjects ");
		while($result = mysqli_fetch_assoc($subjectQuery)){	
			?>
				<div class="col-sm-3" style="margin-top: 10px;">
					<input type="radio" name="radio-subject" id="radio-<?php echo $result['row'];?>-0" onclick="_radioCheckedRecord('<?php echo $result['row'];?>')" style="height: 10px; width: 10px; padding: 1px; margin-top: 5px;">
					<label for="radio-<?php echo $result['row'];?>-0" style="margin-right:10px">&nbsp;&nbsp;<?php echo $result['subject'];?></label>
				</div>
			<?php
		}
	}

	?>
	<script>
		function radioCheckedRecord(subject){
			dateNow = "";
			if($('#sel-date').val() == ''){
				dateNow = "<?php echo date('M-d-Y'); ?>";
			}
			else{
				dateNow = $('#sel-date').val();
			}
			facId = "<?php echo $row; ?>";

			$.ajax({
				data: 'subject='+subject+"&facId="+facId+"&date="+dateNow,
				method: 'post',
				url: 'attendanceFilteredSubjectsinRecord.php',
			}).done( function (data){
				$('#curdate0').html(data);
			});
		}
		function _radioCheckedRecord(subject){
			dateNow = "";
			if($('#sel-date').val() == ''){
				dateNow = "<?php echo date('M-d-Y'); ?>";
			}
			else{
				dateNow = $('#sel-date').val();
			}
			facId = "<?php echo $row; ?>";

			$.ajax({
				data: 'subject='+subject+"&date="+dateNow,
				method: 'post',
				url: 'attendanceFilteredSubjectsinRecord.php',
			}).done( function (data){
				$('#curdate0').html(data);
			});
		}
	</script>
	<div class="row"><br></div>
	<div class="row" id="curdate0">
		<div class="col-md-12">
			<div class="table-responsive">
			<table id="datatable-daily-attendance-record" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th></th>
							<th>Student's Name</th>
							<th>Grade</th>
							<th>Subject</th>
							<th>Status</th>
							<?php 
								if($position == "Super Administrator") { 
									echo "<th>Teacher</th>"; 
								}
							?>
							<th><center>Edit</center></th>
							<th><center>Delete</center></th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th></th>
							<th>Student's Name</th>
							<th>Grade</th>
							<th>Subject</th>
							<th>Status</th>
							<?php 
								if($position == "Super Administrator") { 
									echo "<th>Teacher</th>"; 
								}
							?>
							<th><center>Edit</center></th>
							<th><center>Delete</center></th>
						</tr>
					</tfoot>
					<tbody>
						<?php
							$current_date = date('Y-m-d');
							$attResult = '';
							if ($position == "Administrator") { $attResult = mysqli_query($mysqli, "SELECT * from attendance WHERE attendance_date = '$current_date' AND faculty = '$row' "); }
							else{ $attResult = mysqli_query($mysqli, "SELECT * from attendance WHERE attendance_date = '$current_date' "); }
							while ($r = mysqli_fetch_assoc($attResult)){
								$sbjctResult = mysqli_query($mysqli, "SELECT subject from subjects WHERE faculty = '$r[faculty]' AND row = '$r[subject]' ");				
								$stdtResult = mysqli_query($mysqli, "SELECT * from students WHERE id = '$r[studentId]' ");
								$s = mysqli_fetch_assoc($stdtResult);	
								$sbjct = mysqli_fetch_assoc($sbjctResult);
								$mn = $s['mn'];
								if(isset($s['mn'])){
									$mn =$s['mn'];
								}
								else{
									$mn='';
								}
								if(isset($sbjct['subject']) == null){
									echo "<tr>
										<td> $s[id] </td>
										<td> <b>$s[ln]</b>, $s[fn] ".strtoupper($mn[0]).".</td>
										<td> Grade $r[grade] </td>
										<td> --No Subject-- </td>";	
								}
								if($mn == ''){
									echo "<tr>
										<td> $s[id] </td>
										<td> <b>$s[ln]</b>, $s[fn] </td>
										<td> Grade $r[grade] </td>
										<td> $sbjct[subject] </td>";	
								}
								else{
									echo "<tr>
										<td> $s[id] </td>
										<td> <b>$s[ln]</b>, $s[fn] ".strtoupper($mn[0]).".</td>
										<td> Grade $r[grade] </td>
										<td> $sbjct[subject] </td>";	
								}
										if($r['status'] == 0){
											echo "<td> <a class='btn btn-primary btn-xs btn-block btn-status'>Present</a> </td>";
										}if($r['status'] == 1){
											echo "<td> <a class='btn btn-danger btn-xs btn-block btn-status'>Absent</a> </td>";
										}if($r['status'] == 2){
											echo "<td> <a class='btn btn-warning btn-xs btn-block btn-status'>Excused</a> </td>";
										}
										if($position == "Super Administrator"){
											$tchrQry = mysqli_query($mysqli, "SELECT name FROM users WHERE row = '$r[faculty]' ");
											while($t=mysqli_fetch_assoc($tchrQry))
											echo "<td> $t[name]</td>";
										}
								echo 	"<td>
											<center>
												<button class='btn btn-warning btn-xs' data-toggle='modal' data-target='#editStAttendanceRecord".$r['row']."'>
													<span class='glyphicon glyphicon-pencil'></span> Edit
												</button>
											</center>
										</td>
										<td>
											<center>
												<button class='btn btn-danger btn-xs' data-toggle='modal' data-target='#deltStAttendanceRecord".$r['row']."'>
													<span class='glyphicon glyphicon-trash'></span> Delete
												</button>
											</center>
										</td>
									</tr>
									";
						?>
						<?php //include 'deleteAttendanceModal.php'; ?>
						<?php //include 'updateAttendanceModal.php'; ?>
						<?php				 
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
		
	</div>
	<div class="row">
		<div class="col-md-12" style="margin-top: 10px;">
			<form action="exportExcel.php" method="post">
				<input type="hidden" value="<?php echo $row; ?>" id="faculty" name="faculty">
				<input type="hidden" id="subject" name="subject">
				<input type="hidden" id="grade" name="grade">
				<input type="hidden" id="date" name="date">
				
				<button class='btn btn-success btn-block' type="submit" name="submit"><span class="glyphicon glyphicon-download"></span> Download Spreadsheet</button>
			</form>			
		</div>
		<div class="col-md-12" style="margin-top: 10px; margin-bottom: 20px;">
			<form action="exportPdf.php" method="post">
				<input type="hidden" value="<?php echo $row; ?>" id="_faculty" name="_faculty">
				<input type="hidden" id="_subject" name="_subject">
				<input type="hidden" id="_grade" name="_grade">
				<input type="hidden" id="_date" name="_date">
				
				<button class='btn btn-primary btn-block' type="submit" name="submit"><span class="glyphicon glyphicon-download"></span> Download PDF</button>
			</form>
		</div>		
	</div>
</div>
<script type="text/javascript">
	function speakAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Student's  Attendance  was  Added Successfully!";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakUpdateAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Student's  Attendance  was  updated Successfully!";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakDeleteAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Student's attendance was deleted!";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakErrorAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Student's attendance was already recorded!";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakEmptyAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Please choose and fill Student's attendance status.";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}

	function speakEmptyTeacherAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Please Select an Instructor for the record.";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}
	function speakEmptySubjectAttendance(){
		var msg = new SpeechSynthesisUtterance();
		msg.text = "Please Select a Subject for the record.";
		msg.pitch = 2;
		msg.speed = 0;
		window.speechSynthesis.speak(msg);
	}
</script>
<script>  
	$('#datatable-daily-attendance-record').dataTable();
	$("[data-toggle=tooltip]").tooltip();
</script>
<script type="text/javascript">	
	var position = $('#position-id').val();
	var afacNo;
	var numrows;
	var id = [];
	var st = [];
	let status_col_0 =[];
	let id_col_0 = [];
	var filtered_ids;
	var filtered_sts;
	var subjects = <?php echo "['".implode("','", $arrarSubjects)."']" ?>

	function selectFaculty() {
		$('#admin_Id').val($('#facAtd').val());
		var fac = $('#admin_Id').val();
		// console.log(fac);
		var sfac = "fac="+fac;
		$.ajax({
			method: 'post',
			data: sfac,
			url:'showSubject.php',
		}).done( function(data){
			// console.log(data);
			$('#sAtd').html(data);
		});
	}

	function selRef(){
		$('#btn-sel').show();
		$('#facAtd').val('');
		$('#sAtd').val('Subjects');
		$('#sGAtd').val('');
		$('#modalData').html('');
		$('#btn-ref').hide();	

		del_Array_Values();
	}

	// function selSub(){
	// 	var selected_grade = "<?php //echo $grade?>";
	// 	var selected_subject = $('#sAtd').val(); 
	// 	var selected_teacher;
	// 	var selectElement = document.querySelector('#sAtd');
	// 	var output = selectElement.options[selectElement.selectedIndex].value;

	// 	if(position == "Super Administrator")
	// 		selected_teacher = $('#facAtd').val();
	// 	else
	// 		selected_teacher = $('#faculty-id').val();

	// 	if(selected_grade == null ||  selected_subject == null || selected_teacher == null){
	// 		$('#btn-ref').hide();
	// 		$('#btn-sel').show();
	// 	}
	// 	if(output == "Subjects"){
	// 		$('#alert-error-id').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><i class="glyphicon glyphicon-info"></i> No Subject/s are Selected!</div>');
	// 		$('#alert-error-id').show(100).delay(2000).hide(100);
	// 	}
	// 	else{
			
	// 		var sub ;
	// 		if(output == "allSubjects"){
	// 			sub = "selected_grade="+selected_grade+"&selected_subject="+subjectArray+"&selected_teacher="+selected_teacher;
	// 		}
	// 		else{
	// 			sub = "selected_grade="+selected_grade+"&selected_subject="+[selected_subject]+"&selected_teacher="+selected_teacher;
	// 		}
	// 		$.ajax({
	// 			url:'showStudentForAttendance.php',
	// 			type:'post',
	// 			data:sub,
	// 		}).done( function(data){
	// 			$('#modalData').html(data);
	// 			$('#btn-ref').show();
	// 			$('#btn-sel').hide();

	// 		});
	// 	}
	// 	del_Array_Values();

	// }

	function selectDate(){

		var sdate = $('#sel-date').val();
		var sgrade = $('#sel-grade').val();
		var ssubject = $('#sel-subject').val();
		var arraySubjects = subjects;
		var selectElement = document.querySelector('#sel-subject');
		var output = selectElement.options[selectElement.selectedIndex].value;
		var sfacNo;
		if(position == "Super Administrator")
			sfacNo = $('#sel-faculty').val();
		else
			sfacNo = $('#faculty-id').val();

		if(sdate == '' && sgrade == '' && ssubject == '' && sfacNo == ''){
		}
		else{
			var d ;
			if(output == "allSubjects"){
				d = "date="+sdate+"&grade="+sgrade+"&subject="+arraySubjects+"&faculty="+sfacNo;
			}
			else{
				d = "date="+sdate+"&grade="+sgrade+"&subject="+ssubject+"&faculty="+sfacNo;
			} 
			$.ajax({
				method: 'post',
				data: d,
				url:'selectDate.php',
			}).done( function(data){
				// console.log(data);
				$('#curdate0').html(data);
				// $('#sel-date').val('');
				$('#date').val($('#sel-date').val());
				$('#grade').val($('#sel-grade').val());
				$('#subject').val($('#sel-subject').val());
				$('#faculty').val(sfacNo);

				$('#_date').val($('#sel-date').val());
				$('#_grade').val($('#sel-grade').val());
				$('#_subject').val($('#sel-subject').val());
				$('#_faculty').val(sfacNo);
			});
		}
	}
/**
 * update data to database
 **/
	function updateAttendance(rows){
		var row=rows;
		var subject=$('#sStud'+row).val();
		var status=$('#stsStud'+row).val();
		var selectElement = document.querySelector('#sStud'+row);
		var output = selectElement.options[selectElement.selectedIndex].value;
		// var datas="subject="+subject+"&status="+status+"&row="+row;
		if ( status == null || subject == null) {
			$('#alertuStd'+row).html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please fill required empty field/s!</div>');
		}
		else{
			if(output == "allSubjects"){
				d = "subject="+subjects+"&status="+status+"&row="+row
			}
			else{
				d = "subject="+subject+"&status="+status+"&row="+row;
			} 
			$.ajax({
				method:'post',
				url: 'updateAttendance.php',
				data: d,
			}).done(function(data){
				$('#editStAttendanceRecord'+row).modal('hide');
				$('.modal-backdrop').hide();
				attendanceRecordTab();
				$('#alertMessage').html(data);
				hideAlert();
				speakUpdateAttendance();
				console.log(data)
			});
		}	
		document.body.style.overflowY = 'scroll';
	}
/**
 * delete data to database
 **/
	function deleteAttendance(rows){
		var row=rows;
		var datas="row="+row;
		$.ajax({
			method:'post',
			url: 'deleteAttendance.php',
			data: datas,
		}).done(function(data){
			$('#editStAttendanceRecord'+row).modal('hide');
			$('.modal-backdrop').hide();
			attendanceRecordTab();
			$('#alertMessage').html(data);
			hideAlert();
			speakDeleteAttendance();
		});
		document.body.style.overflowY = 'scroll';
	}

	function del_Array_Values(){
			
		id=[];
		st=[];
		id_col_0=[];
		status_col_0=[];
		filtered_id = [];
		filtered_sts = [];
	}
	del_Array_Values();
</script>