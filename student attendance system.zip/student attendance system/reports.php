<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];

    // $percentageofEnrolment;
    // $averagDailyAttendance;
    // $percentageofAttendancefortheMonth;
    $months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September','October', 'November', 'December'];

    // $showModal;
    // $frstFdaySY;
    // $totalAttCount;
    // $totalAttPresentCount;
    // $totalAttAbsentCount;
    // $totalAttExcusedCount;
    // $totalStudents;
    // $totalAttendance;
    // $date = date('M-d-Y');

    // $reportQry = mysqli_query($mysqli, "SELECT * FROM users WHERE row = '$row' ");
    // while($result = mysqli_fetch_assoc( $reportQry)){
    //     if($result['firstFridayStudents'] == null ||
    //      $result['firstFridayStudents'] == '' || 
    //      empty( $result['firstFridayStudents'])){
    //         $showModal= 'show';
    //      }
    //      else{
    //         $showModal= 'hide';
    //         $frstFdaySY = $result['firstFridayStudents'];
    //         // echo $result['firstFridayStudents'];         
    //      }
    // }
?>

<div class="container">
	<div class="row">
		<div class="col-md-12" >
			<h3>Reports</h3>
            <div class=" alert alert-warning">
                <p><label  style="color:red">NOTE:</label> Please make sure to always update the number of students before doing your report.</p>   
            </div>
		</div>
	</div>

    <!-- AUTO GENERATING REPORT -->
    <div class="row">
        <div class="col-md-12 ">
            <div class="col-md-12 alert alert-info">
                <?php
                if($position == 'Super Administrator'){
                    ?>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-sm-12">
                                <label for="enrolmentPercentage">Teacher<b style="color:red">*</b></label>
                            </div>
                            <div class="col-sm-12">
                                <select class="form-control" name="" id="select-Teacher" >
                                    <?php
                                        $resTec = mysqli_query($mysqli, "SELECT * FROM users WHERE status = 1 ");
                                        while($result = mysqli_fetch_assoc($resTec)){
                                        ?>
                                            <option value='<?php echo $result['row']?>'> <?php echo $result['name']?></option>
                                        <?php
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div class="form-group">
                    <div class="row">
                        <div class="col-sm-12">
                            <label for="enrolmentPercentage">Enrolment as of 1st friday of the school year<b style="color:red">*</b></label>
                        </div>
                        <div class="col-sm-6">
                            <label for="male-enrolees">Male Students<b style="color:red">*</b></label>
                            <input type="number" class="form-control" id="male-enrolees" min='1' oninput="this.value = !!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null" placeholder="Total count of Male Students">
                        </div>
                        <div class="col-sm-6">
                            <label for="female-enrolees">Female Students<b style="color:red">*</b></label>
                            <input type="number" class="form-control" id="female-enrolees" min='1' oninput="this.value = !!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null" placeholder="Total count of Female Students">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <div class="col-sm-6">
                            <label for="no-of-schooldays">Number of school days<b style="color:red">*</b></label>
                            <input type="number" class="form-control" id="no-of-schooldays" min='1' oninput="this.value = !!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null" placeholder="Please input a number">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row ">
        <?php
            $already_selected_value = date('Y');
            $earliest_year = 1950;
        ?>
        <div class="col-md-12" style="margin-bottom: 20px; ">
            <div class="alert  alert-info ">
                <div class="row">
                    <div class="form-group">
                        <div class="col-md-4">
                            <label for="">Select Month<b style="color:red">*</b></label>
                            <select name="" id="select-month" class="form-control">
                                <?php
                                    foreach($months as $month){ 
                                        $selected = date('M').substr($month,3);
                                        print '<option value="'.$month.'"'.($month === $selected ? ' selected=selected' : '').'>'.$month.'</option>';
                                    }
                                ?>
                            </select>            
                        </div>
                        <div class="col-md-4">
                            <label for="">Select Year<b style="color:red">*</b></label>
                            <select name="" id="select-year" class="form-control">
                                <?php
                                    foreach (range(date('Y'), $earliest_year) as $x) {
                                        print '<option value="'.$x.'"'.($x === $already_selected_value ? ' selected=selected ' : '').'>'.$x.'</option>';
                                    }
                                ?>
                            </select>            
                        </div>
                        <div class="col-md-4">
                            <button style="margin-top: 13px" class="btn btn-primary form-control" id="sf2-button" onclick="generateSF2Report()"><span class="glyphicon glyphicon-retweet"></span>  Generate SF2 Report</button>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <span id="error-report"></span>  
                    </div>                  
                </div>

            </div>
        </div> 
        <div class="col-md-12" >  

        </div>
        <script>
            var month;
            var shortMonth;
            var date;
            var dayOne;
            var daydayEnd;

            function changeMonth(){
                alert($('#select-month').val())
            }
            
            function changeYear(){
                alert($('#select-year').val())
            }

            function generateSF2Report(){

                switch($('#select-month').val()) {
                    case 'January':
                        // code block
                        month = 'Jan'
                        shortMonth = '1'
                        break;
                    case 'February':
                        // code block
                        month = 'Feb'
                        shortMonth = '2'
                        break;
                    case 'March':
                        // code block
                        month = 'Mar'
                        shortMonth = '3'
                        break;
                    case 'April':
                        // code block
                        month = 'Apr'
                        shortMonth = '4'
                        break;
                    case 'May':
                        // code block
                        month = 'May'
                        shortMonth = '5'
                        break;
                    case 'June':
                        // code block
                        month = 'Jun'
                        shortMonth = '6'
                        break;
                    case 'July':
                        // code block
                        month = 'Jul'
                        shortMonth = '7'
                        break;
                    case 'August':
                        // code block
                        month = 'Aug'
                        shortMonth = '8'
                        break;
                    case 'September':
                        // code block
                        month = 'Sep'
                        shortMonth = '9'
                        break;
                    case 'October':
                        // code block
                        month = 'Oct'
                        shortMonth = '10'
                        break;
                    case 'November':
                        // code block
                        month = 'Nov'
                        shortMonth = '11'
                        break;
                    case 'December':
                        // code block
                        month = 'Dec'
                        shortMonth = '12'
                    default:
                    // code block
                }
                let date = new Date();
                dayOne = month+"-01-"+$('#select-year').val();
                dayEnd = month+"-"+daysInMonth(shortMonth, $('#select-year').val())+"-"+$('#select-year').val();
                $('#day-one').val(dayOne);
                $('#day-end').val(dayEnd);
                tmaleEnrolees = document.getElementById('male-enrolees');
                tfemaleEnrolees = document.getElementById('female-enrolees');
                noofSchooldays = document.getElementById('no-of-schooldays');

                if((tmaleEnrolees.value == null || tfemaleEnrolees.value == null || noofSchooldays.value == null)||
                (tmaleEnrolees.value == '' || tfemaleEnrolees.value == '' || noofSchooldays.value == '')){
                    $('#error-report').html('<div class="alert alert-warning alert-dismissible"><a href="#" id="focusMe" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please fill required empty field/s!</div>');

                }else{
                    data = 'dayOne='+$('#day-one').val()+'&dayEnd='+$('#day-end').val()+"&fmale="+tmaleEnrolees.value+"&ffemale="+tfemaleEnrolees.value+"&noshooldays="+noofSchooldays.value+"&selectTeacher="+$('#select-Teacher').val();
                    $.ajax({
                        data: data,
                        method: 'post',
                        url:'getDatePasstoPHP.php',
                    }).done( function(data){
                        console.log(data)
                        tmaleEnrolees.value = ''
                        tfemaleEnrolees.value = ''
                        noofSchooldays.value = ''
                        $('#downloadSF2').removeAttr('disabled', true);
                    });
                }
            }
            function daysInMonth(month, year) {
                return new Date(year, month, 0).getDate();
            }
        </script> 
    </div>
    <!-- AUTO GENERATING REPORT -->
    <div class="col-sm-12" id="or">
        <!-- <center><h3 id="-or-"><b style="color:red">--OR--</b></h3></center> -->
    </div>

    <!-- DOWNLOAD SF2 -->
    <div class="row" style="margin-bottom: 20px; margin-top: 20px">
        <input type="hidden" id="day-one" >
        <input type="hidden" id="day-end" >
        <div class="col-md-12">
            <div class="alert alert-info">
                <div class="form-group">
                    <div class="col-md-12">
                        <p class=""><label for="" style="color:red">NOTE:</label> Before clicking the button please select first the Date and then generate the SF2 REPORT to load the data properly to the xlsx file.</p>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-12">
                        <a class="btn btn-success pull-right" href="download.php" onclick="$('#downloadSF2').attr('disabled','disabled');" disabled='disabled' id="downloadSF2"><span class="glyphicon glyphicon-download"></span> Download SF2 REPORT</a>
                    </div>
                    <div class="col-md-12" style="margin-bottom: 40px;"></div>
                </div> 
            </div> 
        </div>
    </div>
    <!-- END DOWNLOAD SF2 -->

    <div class="row" style="margin-bottom: 20px; margin-top: 20px"></div>

	<div class="row">
	<script>
        $(document).ready(function() {
            $('#datatableStud').dataTable();
            $("[data-toggle=tooltip]").tooltip();
        });
    </script>

    <div class="row">

    </div>


	</div>
</div>