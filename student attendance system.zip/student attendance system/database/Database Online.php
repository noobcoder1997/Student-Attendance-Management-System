<?php
	$server = 'sql307.infinityfree.com';
	$dbuser = 'if0_37247809';
	$dbpass = 'IfgvO2BNlcF2sT';
	$db = 'if0_37247809_db_sas';
	
	$mysqli = new mysqli($server, $dbuser, $dbpass, $db);
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
?>