<?php
	$server = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db = 'db_sas';
	
	$mysqli = new mysqli($server, $dbuser, $dbpass, $db);
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
?>