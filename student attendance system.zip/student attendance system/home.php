<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];
	$loadBody = "dashboardTab()";
	$resultID = "SELECT * FROM users WHERE row='$row' AND position='$position';";

	$result = mysqli_query($mysqli, $resultID);

    if ($r = mysqli_fetch_assoc($result)){
        if($position == "Administrator" || $position == "Super Administrator" ){
            $name = $r['name'];
        }
        $image = $r['image'];
    }
?>	
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>SAMS - <?php echo $position;?></title>
		<meta charset="utf-8">
		<link REL='shortcut icon' href="images/Every-day-counts-1024x505.png">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/dataTables.bootstrap.css">
		<link rel="stylesheet" href="css/selectize.bootstrap3.min.css">
		<link rel="stylesheet" href="css/normalize.min.css">
		<link rel="stylesheet" href="css/paper.css">
		<!-- <link rel="stylesheet" href="sas-style.css">	 -->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.dataTables.min.js"></script>
		<script src="js/dataTables.bootstrap.js"></script>
		<script src="js/Chart.js"></script>
		<script src="js/jspdf.debug.js"></script>
		<script src="js/selectize.min.js"></script>
	</head>
	<style>
			/* .modal-open {
				overflow: hidden;
				position: fixed;
				width: 100%;
				height: 100%;
			} */
			.btn{
				border-radius: 25px;
			}
			.form-control{
				border-radius: 20px;
			}
			.btn-status{
				padding: 1px;
				margin: 0%;
			}
			.th-colored{
				color: #0480be;
				font-size: 18px;
			}
			.th-centered{
				text-align: center;
				min-width: min(100%, 100%);
			}
			.radio-centered{
				text-align: center;
				width: auto;
				height:auto	;
				vertical-align: top;
			}
			input[type='radio'] {
		    	transform: scale(2);
				margin-top: 25%;
			}
			.previous:hover, .next:hover {
			  background-color: #ddd;
			  color: black;
			}

			.previous, .next{
			  background-color: #f1f1f1;
			  color: black;
			  display: inline-block;
			  padding: 8px 16px;
			}

			.round {
			  border-radius: 50%;
			}
			.pagination>li {
				display: inline;
				padding:0px !important;
				margin:0px !important;
				border:none !important;
			}
			iframe
			{
				height:700px !important;
			}

			@media print
			{    
				.no-print, .no-print *
				{
					display: none !important;
				}
			}

			html{
				position: relative;
				min-height: 100%;
				overflow-x: hidden;
			}
			body{
				padding:0;
				margin: 0;
				background: #e8e8e8;
				overflow-x: hidden;
			}
			@font-face {
				font-family: myFont;
				src: url(fonts/poppins/Poppins-Regular.ttf);
			}

			.navbar{
				box-shadow: 0 0 15px #A9A9A9;
			}

			#wrapper {
				padding-left: 0;
				-webkit-transition: all 0.5s ease;
				-moz-transition: all 0.5s ease;
				-o-transition: all 0.5s ease;
				transition: all 0.5s ease;
				overflow-x: hidden;
			}

			#wrapper.toggled {
				padding-left: 250px;
			}

			#sidebar-wrapper {
				position: fixed;
				left: 250px;
				width: 0;
				height: 100%;
				margin-left: -250px;
				overflow-y: auto;
				box-shadow: 0 0 15px #A9A9A9;
				background: #F8F8F8;
				-webkit-transition: all 0.5s ease;
				-moz-transition: all 0.5s ease;
				-o-transition: all 0.5s ease;
				transition: all 0.5s ease;
				overflow-x: hidden;
			}

			#wrapper.toggled #sidebar-wrapper {
				width: 250px;
			}

			#page-content-wrapper {
				width: 100%;
				position: absolute;
				padding: 15px;
				/* overflow-y: scroll; */
			}

			#wrapper.toggled #page-content-wrapper {
				position: absolute;
				margin-right: -250px;
			}

			/* Sidebar Styles */

			.sidebar-nav {
				position: absolute;
				top: 0;
				width: 250px;
				margin: 0;
				padding: 0;
				list-style: none;
			}

			.sidebar-nav li {
				text-indent: 20px;
				line-height: 40px;
				color: #616161;
			}

			.sidebar-nav li a {
				display: block;
				text-decoration: none;
				color: #5a8dee;
			}
			
			.activeTab{
				text-decoration: none !important;
				color: #fff !important;
				background: #5a8dee !important;
			}

			.sidebar-nav li a:hover {
				text-decoration: none;
				color: #000;
				background: rgba(255,255,255,255);
			}

			.sidebar-nav li a:active,
			.sidebar-nav li a:focus {
				text-decoration: none;
			}

			.sidebar-nav > .sidebar-brand {
				margin-top: 30px;
				margin-right: 25px;
				font-size: 15px;
				color: #5a8dee;
			}

			.navbar-brand{
				color: #5a8dee !important;
			}

			.sidebar-nav > .sidebar-brand a {
				color: #5a8dee;
			}

			.sidebar-nav > .sidebar-brand a:hover {
				color: #000;
				background: none;
			}
			
			.preloaderBg {
				z-index: 10; 
				margin-top: 10%;
				margin-left:auto;
				margin-right:auto;
				text-align: center;
			}

			.preloader {
				margin: auto;
				background: url(images/bethel.png) no-repeat center;
				background-size: 200px;
				animation: spin2 1s ease-in-out infinite ;
				position: relative;
				width: 300px;
				height: 300px;
				z-index: 12;
			}
			
			.preloader:hover{
				animation: spin1 1s ease-in-out infinite ;
				opacity: 1; 
			}

			.preloader2 {
				border: 5px solid #66a7ec;
				border-top: 5px solid #003a75;
				border-bottom: 5px solid #003a75;
				border-radius: 50%;
				box-shadow: 0 0 15px #A9A9A9;
				width: 250px;
				height: 250px;
				animation: spin 1s ease-in-out infinite ;
				position: relative;
				margin: auto;
				top: -275px;
				z-index: 11;
			}
			
			@keyframes spin {
				0% { transform: rotate(0deg); }
				100% { transform: rotate(360deg); }
			}
			
			@keyframes spin1 {
				100% { transform: rotate(0deg); }
				0% { transform: rotate(360deg); }
			}

			@keyframes spin2 {
				0% { 
					-webkit-filter: grayscale(100%);
					filter: grayscale(100%);
					opacity: .3;
				}
				100% { 
					-webkit-filter: grayscale(0%);
					filter: grayscale(0%);
					opacity: 1; 
				}
			}
			
			@media(min-width:768px) {
				#wrapper {
					padding-left: 250px;
				}

				#wrapper.toggled {
					padding-left: 0;
				}

				#sidebar-wrapper {
					width: 250px;
				}

				#wrapper.toggled #sidebar-wrapper {
					width: 0;
				}

				#page-content-wrapper {
					padding: 20px;
					position: relative;
				}

				#wrapper.toggled #page-content-wrapper {
					position: relative;
					margin-right: 0;
				}
			}
			.logout{
				display: none;
			}
			.sidebar-button{
				display: none;
			}
			.text-header:after{
				content: 'Student Attendance Management System (SAMS)';
			}
			.preClass{
				padding: 10px; 
				background: #F5ee97; 
				color: #CB8E37;
				border-radius: 3px;
			}
			@media only screen and (max-width: 768px) {
				.preClass{
					margin: auto;
					width: 80%;
				}
				.nav{
					display: none;
				}
				.logout{
					display: block;
				}
				.sidebar-button{
					display: block;
				}
				.text-header:after{
					content: 'SAMS';
				}
				.preloaderBg {
					margin-top: auto;
				}
			}
			@media only screen and (max-width: 400px) {
				.preloaderBg {
					margin-top: 40%;
				}
			}
 
			/* ::-webkit-scrollbar {
				width: 3px;
			}
			:hover::-webkit-scrollbar {
				width: 10px;
			}

			::-webkit-scrollbar-track {
				-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
				border-radius: 5px;
			}
			::-webkit-scrollbar-thumb {
				-webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
				border-radius: 5px; 
			}*/
			.container{
				box-shadow: 0 0 15px #A9A9A9;
				border-radius: 3px;
				background:#f7f7f7;
				color: #616161;
			}
			.modal-header {
				padding:9px 15px;
				background-color: #0480be;
				color: #fff;
				-webkit-border-top-left-radius: 5px;
				-webkit-border-top-right-radius: 5px;
				-moz-border-radius-topleft: 5px;
				-moz-border-radius-topright: 5px;
			}
	 </style>
	<body onload="<?php echo $loadBody;?>;">
		<div id="wrapper">
			<div id="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li class="sidebar-brand">
						<center>
							<a data-toggle="modal" data-target="#imageModal" id="btn2">
								<?php
									if($image == "" or $image == "None" or $image == 'images/default.jpg'){
								?>
										<img src="images/default.jpg" class="img-circle" alt="Profile Photo" height="160px;" width="160px;">
								<?php
									}else{
								?>
										<img src="<?php print_r($image);?>" class="img-circle img-display" alt="Profile Photo" height="160px;" width="160px;" style="box-shadow: 0 0 15px #A9A9A9;object-fit: cover;">
								<?php
									}
								?>
							</a>
						</center>
						<center>
							<?php print_r(strtoupper("<strong>$name</strong>"));?>
						</center>
					</li>	
					<hr>

					<li>MY</li>		

					<li>
						<a href="#dbdTab" data-toggle="tab" id="btn1" onclick="dashboardTab();" class="activeTab"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a>
					</li>
					<li>
						<a data-toggle="modal" data-target="#profileModal" id="btn2"><span class="glyphicon glyphicon-cog"></span> Profile</a>
					</li>
					<?php
						if($position == 'Super Administrator'){
					?>
					<li>
						<a href="#admnTab" data-toggle="tab" id="btn6" onclick="adminTab();"><span class="glyphicon glyphicon-user"></span> Administrators</a>
					</li>
					<?php 
						}
					?>
					<li>SETUP</li>
	
					<li>
						<a href="#atdTab" data-toggle="tab" id="btn4" onclick="attendanceTab();"><span class="glyphicon glyphicon-th-list"></span> Attendance</a>
					</li>
                    <li>
						<a href="#stdTab" data-toggle="tab" id="btn11" onclick="studentTab();"><span class="glyphicon glyphicon-user"></span> Students</a>
					</li>
					<li>
						<a href="#sbjctTab" data-toggle="tab" id="btn5" onclick="subjectTab();"><span class="glyphicon glyphicon-tasks"></span> Subjects</a>
					</li>
					<li>REPORTS</li>

					<li>
						<a href="#atdRTab" data-toggle="tab" id="btn7" onclick="attendanceRecordTab();"><span class="glyphicon glyphicon-list-alt"></span> Attendance Record</a>
					</li>
					<li>
						<a href="#reprtTab" data-toggle="tab" id="btn12" onclick="reportTab();"><span class="s	glyphicon glyphicon-folder-close"></span> SF2 Report</a>
					</li>

                <hr>
					<span class="logout">
						<li>
							<a data-toggle="modal" data-target="#logoutModal" id="btn15"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
						</li>
					</span>
				</ul>
			</div>
			<div id="page-content-wrapper">
				<nav class="navbar navbar-default">
					<div class="container-fluid">
						<div class="navbar-header">
						<a href="#menu-toggle" class="navbar-brand btn sidebar-button" id="menu-toggle">☰</a>
							<a class="navbar-brand" rel="home" href="home.php" title="SAMS">
								<img style="max-width:35px; margin-top: -11px; margin-bottom: -7px;" src="images/Every-day-counts-1024x505.png">
								<span class="text-header"></span>
							</a>
						</div>
						<ul class="nav navbar-nav navbar-right">
							<li><a data-toggle="modal" data-target="#logoutModal" id="btn16"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
						</ul>
					</div>
				</nav>
				<div id="alertMessage" width="100%"></div>
				<div class="tab-content">
					<div id="dbdTab" class="tab-pane fade  in active">
						<div id="dashboardTab">
							<div class="preloaderBg" id="preloader" onload="preloader()">
								<div class="preloader"></div>
								<div class="preloader2"></div>
							</div>
						</div>
					</div>
					<div id="admnTab" class="tab-pane fade">
						<div id="administratorTab">
							<div class="preloaderBg" id="preloader" onload="preloader()">
								<div class="preloader"></div>
								<div class="preloader2"></div>
							</div>
						</div>
					</div>
					<div id="atdTab" class="tab-pane fade">
						<div id="attendanceTab">
							<div class="preloaderBg" id="preloader" onload="preloader()">
								<div class="preloader"></div>
								<div class="preloader2"></div>
							</div>
						</div>
					</div>
					<div id="atdRTab" class="tab-pane fade">
						<div id="attendanceRecordTab">
							<div class="preloaderBg" id="preloader" onload="preloader()">
								<div class="preloader"></div>
								<div class="preloader2"></div>
							</div>
						</div>
					</div>
					<div id="sbjctTab" class="tab-pane fade">
						<div id="subjectTab">
							<div class="preloaderBg" id="preloader" onload="preloader()">
								<div class="preloader"></div>
								<div class="preloader2"></div>
							</div>
						</div>
					</div>
					<div id="stdTab" class="tab-pane fade">
						<div id="studentTab">
							<div class="preloaderBg" id="preloader" onload="preloader()">
								<div class="preloader"></div>
								<div class="preloader2"></div>
							</div>
						</div>
					</div>
					<div id="reprtTab" class="tab-pane fade">
						<div id="reportTab">
							<div class="preloaderBg" id="preloader" onload="preloader()">
								<div class="preloader"></div>
								<div class="preloader2"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<input type="hidden" id="faculty-id" value="<?php echo $row; ?>">
		<input type="hidden" id="position-id" value="<?php echo $position; ?>">
	</body>
</html>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog" data-backdrop="static" data-keyboad="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <center><h4 class="modal-title">Are you there?</h4></center>
      </div>
      <div class="modal-body">
        <h5>Hi! This session is going to end soon. Please save your work or click the continue button below to continue working.</h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="continueWork();"><span class="glyphicon glyphicon-remove"></span> Continue</button>
        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-ok"></span> Close</button>
      </div>
    </div>
  </div>
</div>
<?php include 'changePassModal.php';?>
<?php include 'logoutModal.php';?>
<?php include 'updatePictureModal.php';?>
<script type="text/javascript">
	const duration = 1800000 // 30 minutes
	// let timeout = 1800000 // 30 minutes

	// User pushes the button
	function continueWork(){
		$('#myModal').modal('hide');
		clearTimeout(timer);
	}

	// timer start when the user is in
	userTimer = setInterval(function(){
		$('#myModal').modal('show');
		startTimeout();
	}, duration);

	// timer start when user does not click the continue button 
	function startTimeout(){
		timer = setTimeout(() => {
			clearInterval(userTimer);
			sessionStorage.clear();
			window.location.href="logout.php";
		},duration);
	}
	
 </script>
 <script type="text/javascript">	
	(function hideMyURL() {
		var re = new RegExp(/^.*\//);
		window.history.pushState("object or string", "Title", re.exec(window.location.href));
	})();
	document.addEventListener("keyup", function (e) {
		var keyCode = e.keyCode ? e.keyCode : e.which;
        if (keyCode == 44) {
            stopPrntScr();
        }
    });
	
	function stopPrntScr() {
        var inpFld = document.createElement("input");
        inpFld.setAttribute("value", ".");
        inpFld.setAttribute("width", "0");
        inpFld.style.height = "0px";
        inpFld.style.width = "0px";
        inpFld.style.border = "0px";
        document.body.appendChild(inpFld);
        inpFld.select();
        document.execCommand("copy");
        inpFld.remove(inpFld);
    }
	
	function AccessClipboardData() {
        try {
            window.clipboardData.setData('text', "Access   Restricted");
        } catch (err) {
        }
    }
	
    setInterval("AccessClipboardData()", 300);
	
	$("#btn1, #bt3nn, #btn4, #btn5, #btn6, #btn7, #btn8, #btn9, #btn10, #btn11, #btn12, #btn13, #btn14, #btn17, #btn18").click(function (e) {     
		$("#btn1, #bt3nn, #btn4, #btn5, #btn6, #btn7, #btn8, #btn9, #btn10, #btn11, #btn12, #btn13, #btn14, #btn17, #btn18").removeClass("activeTab");   
		$( this ).addClass("activeTab");
	});
	
	$("#btn1, #btn2, #bt3n, #btn4, #btn5, #btn6, #btn7, #btn8, #btn9, #btn10, #btn11, #btn12, #btn13, #btn14, #btn15, #btn16, #btn17, #btn18").click(function(e) {
		if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
			e.preventDefault();
			$("#wrapper").toggleClass("toggled");
		}
	});
	
	$("#menu-toggle").click(function(e) {
		e.preventDefault();
		$("#wrapper").toggleClass("toggled");
	});
	
	var preloadTime;

	function preloader() {
		preloadTime = setTimeout(showPage, 1000);
	}

	function showPage() {
		document.getElementById("preloader").style.display = "none";
	}

	function adminTab(){
		$.ajax({
			type: "GET",
			url: "administrator.php"
		}).done(function(data){
			$('#administratorTab').html(data);
		});
	}
	
	function dashboardTab(){
		$.ajax({
			type: "GET",
			url: "dashboard.php"
		}).done(function(data){
			$('#dashboardTab').html(data);
		});
	}
	
	function attendanceTab(){
		$.ajax({
			type: "GET",
			url: "attendance.php"
		}).done(function(data){
			$('#attendanceTab').html(data);
		});
	}	
	
	function attendanceRecordTab(){
		$.ajax({
			type: "GET",
			url: "attendanceRecord.php"
		}).done(function(data){
			$('#attendanceRecordTab').html(data);
		});
	}

	function subjectTab(){
		$.ajax({
			type: "GET",
			url: "subject.php"
		}).done(function(data){
			$('#subjectTab').html(data);
		});
	}

	function studentTab(){
		$.ajax({
			type: "GET",
			url: "students.php"
		}).done(function(data){
			$('#studentTab').html(data);
		});
	}

	function reportTab(){
		$.ajax({
			type: "GET",
			url: "reports.php"
		}).done(function(data){
			$('#reportTab').html(data);
		});
	}
	
	function hideAlert(){
		$("#alertMessage").fadeTo(3000, 500).slideUp(500, function(){			
		});
		$("#alertSched").fadeTo(3000, 500).slideUp(500, function(){			
		});
	}
 </script>