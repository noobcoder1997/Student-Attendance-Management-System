<?php
include_once 'dbConfig.php';

$username=htmlentities(stripcslashes(mysqli_real_escape_string($mysqli, $_POST['username'])));
$message;
$stmt=$mysqli->prepare("SELECT username FROM users WHERE username = ? ");
$stmt->bind_param('s', $username);
$stmt->execute();
$result=$stmt->get_result();
if($row = $result->fetch_Array(MYSQLI_ASSOC)){
    $message=1;
}
else{
    $message=0;
}
echo $message;
$stmt->close();
?>