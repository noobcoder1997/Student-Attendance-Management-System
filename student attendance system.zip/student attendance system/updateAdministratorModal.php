<div class="modal fade" id="editAdmin<?php echo $rAdmn['row']; ?>" role="dialog"  data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading">Update an Administrator</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="userAdmin<?php echo $rAdmn['row']; ?>">Username<b style="color:red">*</b></label>
					<input class="form-control" id="userAdmin<?php echo $rAdmn['row']; ?>" type="text" placeholder="Username" value='<?php echo $rAdmn['username']; ?>'>
				</div>
				<div class="form-group">
					<label for="passAdmin<?php echo $rAdmn['row']; ?>">Password<b style="color:red">*</b></label>
					<input class="form-control" id="passAdmin<?php echo $rAdmn['row']; ?>" type="text" placeholder="Password" value='<?php echo $rAdmn['password']; ?>'>
				</div>
				<div class="form-group">
					<label for="nameAdmin<?php echo $rAdmn['row']; ?>">Complete Name<b style="color:red">*</b></label>
					<input class="form-control" id="nameAdmin<?php echo $rAdmn['row']; ?>" type="text" placeholder="Complete Name" value='<?php echo $rAdmn['name']; ?>'>
				</div>
				<script>
					$(document).ready(function() {
						$("#editAdmin"+<?php echo $rAdmn['row']; ?>).on("hidden.bs.modal", function() {
							adminTab();
						})
					});
				</script>
				<span id="alertAdmn<?php echo $rAdmn['row']; ?>"></span>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-block" onclick="editAdmin(<?php echo $rAdmn['row']; ?>);"><span class="glyphicon glyphicon-ok-sign"></span> Save Changes</button>
			</div>
		</div>
	</div>
</div>
