<?php

	include_once 'dbConfig.php';

	$username = htmlentities(mysqli_real_escape_string($mysqli, $_POST['user']));
	$fnim = htmlentities(mysqli_real_escape_string($mysqli, $_POST['fnim']));
	$lnim = htmlentities(mysqli_real_escape_string($mysqli, $_POST['lnim']));
	$mnim = htmlentities(mysqli_real_escape_string($mysqli, $_POST['mnim']));
	$p1 = htmlentities(mysqli_real_escape_string($mysqli, $_POST['pass1']));
	$p0 = htmlentities(mysqli_real_escape_string($mysqli, $_POST['pass0']));
	$position = htmlentities(mysqli_real_escape_string($mysqli, 'Administrator'));
	$fullname = $fnim." ".$mnim." ".$lnim;
	$pass = $p1 = $p0;
	$pass = htmlentities(mysqli_real_escape_string($mysqli, md5($pass)));
	$image = 'images/default.jpg';

	$mess;

	if(!empty($_FILES["image"]["tmp_name"])){
		// $folder_name=$_POST['image']; 
		// $output_dir = @'photo'; 
		// 	if (!file_exists($output_dir . $folder_name))//checking if folder exist 
		// 	{ 
		// 		@mkdir($output_dir . $folder_name, 0777);//making folder 
			// } 
		$fileinfo=PATHINFO($_FILES["image"]["name"]);
		$newFilename=$fileinfo['filename'] ."." . $fileinfo['extension'];
		move_uploaded_file($_FILES["image"]["tmp_name"],"photo/" . $newFilename);
		$location="photo/" . $newFilename; 

		$stmt = $mysqli->prepare("INSERT INTO users (username, name, password, image, position)VALUES(?,?,?,?,?)");
		$stmt->bind_param("sssss", $username, $fullname, $pass, $location, $position);
		$stmt->execute();
	}
	else{
		$stmt = $mysqli->prepare("INSERT INTO users (username, name, password, image, position)VALUES(?,?,?,?,?)");
		$stmt->bind_param("sssss", $username, $fullname, $pass, $image, $position);
		$stmt->execute();
	}	
	$mess = 1;
	if(isset($mess)){
		echo $_SESSION['message']='Successfully Signed in!';
		// header('location: sign-up.php');
		echo "<script>location.replace('sign-up.php')</script>";
	}
	else{
		echo $_SESSION['message']='Failed Signed in!';
		// header('location: sign-up.php');
		echo "<script>location.replace('sign-up.php')</script>";
	}
?>