<?php
	if(isset($_SESSION['userStatus'])){
		header('location: home.php');
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>SAMS - Create New Password Page</title>
		<meta charset="utf-8">
		<link REL='shortcut icon' href="images/bethel.png">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script>
			(function hideMyURL() {
				var re = new RegExp(/^.*\//);
				window.history.pushState("object or string", "Title", re.exec(window.location.href));
			})();
		</script>
		<style>
			html{
				position: relative;
				min-height: 100%;
			}
			body{
				padding:0;
				margin: 0;
				background: #e8e8e8;
			}
			@font-face {
				font-family: myFont;
				src: url(fonts/poppins/Poppins-Regular.ttf);
			}
			h3{
				color: #5a8dee;
				font-family: myFont;
			}
			.login-form{
				margin-top:20px;
				font-family: myFont;
			}
			.box{
				display: flex;
				flex-flow: row wrap;
				margin-top: 50px;
				box-shadow: 0 0 15px #A9A9A9;
				border-radius: 10px;
			}
			.login-tab{
				height: auto;
				border-radius: 10px 0px 0px 10px;
				color: #002D62;
				background-color: #fff;
				overflow: hidden;
				padding: 20px;
			}
			@media only screen and (max-width: 768px) {
				.login-tab{
					border-radius: 10px 10px 0px 0px;
				}
				.box{
					margin: 10px 2px 2px 2px;
				}
			}
			button{
				margin-top: 15px;
			}
			.btn{
				border-radius: 20px;
			}
			input[type='text'],input[type='password']{
				border-radius: 20px;
			}
		</style>
	</head>
	<body>
		<div class="container-fluid">
            <div class="col-sm-12">
            <div class="col-sm-12" id="ask-username" >
				<div class="row">
					<div class="col-sm-2"></div>
					<div class="col-sm-8">
						<div class="row box">
							<div class="col-sm-5 login-tab">
								<center>
									<h3>STUDENT ATTENDANCE MANAGEMENT SYSTEM (SAMS)</h3>
								</center>
								<div class="login-form">
									<span id="alertMessage"></span>
									<div class="form-group">
										<label for="user">Create Password:</label>
										<input type="password" class="form-control input-lg" id="pass0" placeholder="Password" >
									</div>
                                    <div class="form-group">
										<label for="user">Confirm Password:</label>
										<input type="password" class="form-control input-lg" id="pass1" placeholder="Confirm Password" >
                                        <small id="alert-password"></small>
									</div>
									<button type="button" class="btn btn-primary btn-lg btn-block" onclick="createNewPass()">
										<span class="glyphicon glyphicon-send"></span> Submit
									</button>
									<button type="button" class="btn btn-warning btn-lg btn-block" onclick="location.href='index.php';"style="margin-top: 10px;">
										<span class="glyphicon glyphicon-log-out"></span> Cancel
									</button>
									<br>
									<!-- <center><a class="center" onclick="location.replace('sign-up.php')">No Account? Sign up here.</a></center> -->
								</div>
							</div>
							<div class="col-sm-7">
								<center>
									<!-- attendance matters 2.png -->
									<!-- Every-day-counts-1024x505.png -->
									<img src="images/Every-day-counts-1024x505.png" alt="Login-logo" style="width:100%; margin-top:12rem;">
								</center>
							</div>
						</div>
					</div>
					<div class="col-sm-2"></div>
				</div>
			</div>
            </div>
		</div>
        <input type="hidden" id="username" value='<?php echo $_GET['username']; ?>'>
	</body>
	<script> 
        $('#username').val('<?php echo $_GET['username']; ?>')
        var passInput0 = document.getElementById("pass0");
		var passInput1 = document.getElementById("pass1");
		var alertpass = document.getElementById("alert-password");
		var pass;

		passInput1.onkeyup = function(e){
			if(passInput1.value != passInput0.value){
				$('#alert-password').html('Password did not match!');
				alertpass.style.color="red";
			}
			if(passInput1.value == "" ||  passInput0.value == ""){
				$('#alert-password').html('');
			}
			else if(passInput1.value == passInput0.value){
				$('#alert-password').html('Password match!');
				alertpass.style.color="blue";
				pass = passInput1.value = passInput0.value;
			}
		}
		passInput0.onkeyup = function(e){
			if(passInput1.value != passInput0.value){
				$('#alert-password').html('Password did not match!');
				alertpass.style.color="red";
			}
			if(passInput1.value == "" ||  passInput0.value == ""){
				$('#alert-password').html('');
			}
			else if(passInput1.value != "" && passInput1.value == passInput0.value){
				$('#alert-password').html('Password match!');
				alertpass.style.color="blue";
				pass = passInput1.value = passInput0.value;
			}
		}
        		
        function createNewPass(){
            if(passInput0.value != passInput1.value){
				window.scrollTo(0,0);
				$('#alertMessage').html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Password did not match!</div>');
				$('#pass0').val('');
				$('#pass1').val('');
                $('#alert-password').html('');
			}  
            else{
                $.ajax({
                    method:'post',
                    data: 'password='+pass+"&username="+ $('#username').val(),
                    url:'password-created.php',
                }).done( function( data){
                    alert(data)
                    if(data == 1){
                        $('#alertMessage').html('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Password Updated Successfully</div>');
						window.scrollTo(0,0);
						setTimeout(()=>{
							location.replace('index.php');  
						},2000)
					}
                })
            }
        }

	</script>
</html>
