	<div class="modal fade" id="logoutModal" role="dialog" style="margin-top: 10rem;"  data-backdrop="static" data-keyboad="false">
		<div class="modal-dialog">
			<div class="col-sm-2"></div>
			<div class="col-sm-8"><br/><br/><br/>
				<div class="modal-content" style="padding: 30px;">
					<div class="row">
						<div class="col-sm-12">
							<center>
							<a>
								<?php
									if($image == "" or $image == "None"){
								?>
										<img src="images/default.jpg" class="img-circle" alt="Photo" height="160px;" width="160px;">
								<?php
									}else{
								?>
										<img src="<?php print($image);?>" class="img-circle img-display" alt="Photo" height="160px;" width="160px;" style="box-shadow: 0 0 15px #A9A9A9;object-fit: cover;">
								<?php
									}
								?>
							</a>
						</center>
						</div>
						<div class="col-sm-12">
							<center><h4>Do you want to log out?</h4></center>
						</div>
						<div class="col-sm-12">
							<center>
								<button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
								<a href="logout.php" class="btn btn-primary" style="margin-right:10px;"><span class="glyphicon glyphicon-ok"></span> Yes, log out</a>
							</center>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-2"></div>
		</div>
	</div>