
<div class="modal fade" id="editStud<?php echo $rFcty['row']?>" role="dialog" data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-pencil"></span> Edit Student Data</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="idStud<?php echo $rFcty['row']?>">ID<b style="color:red">*</b></label>
					<input class="form-control" value="<?php echo $rFcty['id']?>" id="idStud<?php echo $rFcty['row']?>" type="text" placeholder="ID">
				</div>
				<div class="form-group">
					<label for="fnStud<?php echo $rFcty['row']?>">First Name<b style="color:red">*</b></label>
					<input class="form-control" value="<?php echo $rFcty['fn']?>" id="fnStud<?php echo $rFcty['row']?>" type="text" placeholder="First Name">
				</div>
				<div class="form-group">
					<label for="mnStud<?php echo $rFcty['row']?>">Middle Name</label>
					<input class="form-control" value="<?php echo $rFcty['mn']?>" id="mnStud<?php echo $rFcty['row']?>" type="text" placeholder="Middle Name">
				</div>
				<div class="form-group">
					<label for="lnStud<?php echo $rFcty['row']?>">Last Name<b style="color:red">*</b></label>
					<input class="form-control" value="<?php echo $rFcty['ln']?>" id="lnStud<?php echo $rFcty['row']?>" type="text" placeholder="Last Name">
				</div>
				<div class="form-group">
					<label for="yrStud<?php echo $rFcty['row']?>">Year<b style="color:red">*</b></label>
					<select class="form-control"  id="yrStud<?php echo $rFcty['row']?>" placeholder="Year">
						<option selected disabled>Grade <?php echo $rFcty['year']?>	</option>
						<?php 
							$resGrde0 =mysqli_query($mysqli, "SELECT * from grades");
							while ($rgrde0 = mysqli_fetch_assoc($resGrde0)){
								echo "<option value=$rgrde0[grade]>Grade $rgrde0[grade]</option>";
							}
						?>
					</select>
				</div>
				<div class="form-group">
					<label for="secStud<?php echo $rFcty['row']?>">Section<b style="color:red">*</b></label>
					<input class="form-control" value="<?php echo $rFcty['section']?>" id="secStud<?php echo $rFcty['row']?>" type="text" placeholder="Section">
				</div>
				<script>
					$(document).ready(function() {
						$("#editStud"+<?php echo $rFcty['row']; ?>).on("hidden.bs.modal", function() {
							studentTab();
						})
					});
				</script>
				<span id="alertuStd<?php echo $rFcty['row']?>"></span>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-warning btn-block" onclick="updateStud('<?php echo $rFcty['row']?>');"><span class="glyphicon glyphicon-ok-sign"></span> Save Changes</button>
			</div>
		</div>
	</div>
</div>