<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
?>
	<div class="modal fade" id="profileModal" role="dialog" data-backdrop="static" data-keyboad="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title custom_align" id="Heading">Edit you profile</h4>
				</div>
				<div class="modal-body">
					<h4><strong>Password</strong></h4>
					<div class="form-group">
						<label for="passProfl">New Password<b style="color:red">*</b></label>
						<input class="form-control" id="passProfl" type="password" placeholder="Will not change if empty">
					</div>
					<div class="form-group">
						<label for="passProfl2">Confirm Password<b style="color:red">*</b></label>
						<input class="form-control" id="passProfl2" type="password" placeholder="Confirm Password">
					</div>
						<div class="form-group">
						<?php 
							$user_qry = mysqli_query($mysqli, "SELECT username FROM users WHERE row = $row");
							while($r = mysqli_fetch_assoc($user_qry)){
						?>
						<!-- <label for="passProfl">Username<b style="color:red">*</b></label> -->
						<!-- <input class="form-control" id="userProf1" type="text" placeholder="Username" value=<?php // echo $r['username']?> > -->
						<?php 
							}
						?>
					</div>	
					<span id="alertPrfl"></span>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary btn-block" onclick="changePasswordProfile();"><span class="glyphicon glyphicon-ok-sign"></span> Save Changes</button>
				</div>
			</div>
		</div>
	</div>

<script type="text/javascript">
	function changePasswordProfile() {
	// alert();
		var row = "<?php echo $row;?>";
		var pass = $('#passProfl').val();
		var pass2 = $('#passProfl2').val();
		if(pass == "" && pass2 == ""){
			$('#alertMessage').html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Password not changed!</div>');
			$('#profileModal').modal('hide');
			$('.modal-backdrop').hide();
			hideAlert();
		}else if(pass != pass2){
			$('#alertPrfl').html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Password not match!</div>');
		}else{
			var datas = "row="+row+"&pass="+pass+"&pass2="+pass2;
			$.ajax({
				type: "POST",
				url: "changePassword.php",
				data: datas
			}).done(function(data){
				$('#profileModal').modal('hide');
				$('.modal-backdrop').hide();
				$('#alertMessage').html(data);
				hideAlert();
				pass=''
				pass2=''
			});
		}
	}
</script>