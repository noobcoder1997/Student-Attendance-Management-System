<?php
include_once 'dbConfig.php';
require_once('loginSession.php');
$row;
$position = $_SESSION['position'];

$dayOne = $_POST['dayOne'];
$fmale = $_POST['fmale'];
$ffemale = $_POST['ffemale'];
$noshooldays = $_POST['noshooldays'];
$dayEnd = $_POST['dayEnd'];
$teacher = $_POST['selectTeacher'];

if($position == 'Super Administrator'){
    $row = $teacher;
}
else if($position == 'Administrator'){
    $row = $_SESSION['row'];
}


require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
    
$path = 'SF2.xlsx';
$spreadsheet = IOFactory::load($path);



$i = 0;
$n = 0;
$x = 0;

$percentageOfEnrolment=0;
$totalDailyAttendance=0;
$AverageDailyAttendance=0;
$percentageOfAttfortheMonth=0;
$fiveAbsencesMale=0;
$fiveAbsencesFemale=0;
$fiveAbsences=0;
$fiveAbsencesArrayMale=array();
$fiveAbsencesArrayFemale=array();

$tregStudent=0;
$totalRegSt0;

$section;
$gradeLevel;

$maleAbsent;
$femaleAbsent;
$registeredStudents;
$malePresent =array();
$femalePresent=array();
$malePresentperDay =array();
$femalePresentperDay=array();
$maleAbsentperDay =array();
$femaleAbsentperDay=array();
$totalPresentinMonth = array();
$dates=array();
$ids=array();
$males=array();
$females=array();
$columns = array('F','H','I','J','K','L','N','O','P','Q','R','T','U','V','X','Z','AB','AC','AD','AE','AF','AI','AJ','AK');


$attendanceQry =  mysqli_query($mysqli, "SELECT *, COUNT(studentId) AS student FROM attendance WHERE faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date ");

$attendanceCountQry =  mysqli_query($mysqli, "SELECT COUNT(*) AS 'rows' FROM attendance WHERE faculty = '$row' ");
$attendanceCountPresentQry =  mysqli_query($mysqli, "SELECT COUNT(*) AS 'rows' FROM attendance WHERE faculty = '$row' AND status = '0' ");
$attendanceCountAbsentQry =  mysqli_query($mysqli, "SELECT COUNT(*) AS 'rows' FROM attendance WHERE faculty = '$row' AND status = '1' ");
$attendanceCountExcusedQry =  mysqli_query($mysqli, "SELECT COUNT(*) AS 'rows' FROM attendance WHERE faculty = '$row' AND status = '2' ");

$studentQry =  mysqli_query($mysqli, "SELECT COUNT(*) as students FROM students WHERE faculty = '$row' ");

while($student = mysqli_fetch_assoc($attendanceCountQry)){
    $totalAttCount = $student['rows']; 
}
while($studentPresent = mysqli_fetch_assoc($attendanceCountPresentQry)){
    $totalAttPresentCount = $studentPresent['rows'];
}
while($studentAbsent = mysqli_fetch_assoc($attendanceCountAbsentQry)){
    $totalAttAbsentCount = $studentAbsent['rows'];
}
while($studentExcused = mysqli_fetch_assoc($attendanceCountExcusedQry)){
    $totalAttExcusedCount = $studentExcused['rows'];
}
while($st = mysqli_fetch_assoc($attendanceQry)){
    
//    echo $st['student'];
//    echo $st['faculty'];
}
if($st = mysqli_fetch_assoc($studentQry)){
    
    // echo $st['students'];
}

//Storing all dates in attendance
$dateQry = mysqli_query($mysqli, "SELECT attendance_date FROM attendance WHERE faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date");
while($resDt = mysqli_fetch_assoc($dateQry)){
    array_push($dates, $resDt['attendance_date']);
}
//End Storing all dates in attendance

// Get week days in a particular month
$fDay;
$mDay;
$time_input = strtotime($dayOne);
$date = getDate($time_input);
$fDay = $date['weekday'];
$mDay = $date['mday'];
$Month = $date['month'];
$Year = $date['year'];

$workdays = array();
$type = CAL_GREGORIAN;
$month = $date['mon']; // Month ID, 1 through to 12.
$year = date('Y'); // Year in 4 digit 2009 format.
$day_count = cal_days_in_month($type, $month, $year); // Get the amount of days

for ($i = 1; $i <= $day_count; $i++) {
    $date = $year.'/'.$month.'/'.$i; //format date
    $get_name = date('l', strtotime($date)); //get week day
    $day_name = substr($get_name, 0, 3); // Trim day name to 3 chars

    //if not a weekend add day to array
    if($day_name != 'Sun' && $day_name != 'Sat'){
        $workdays[] = $i;
    }

}
// END Get week days in a particular month

// Display school year
$spreadsheet->getActiveSheet()->setCellValue('M3', $Year);
// END Display school year

// Get grade level AND display in the file
$gradeLevelQry=mysqli_query($mysqli, "SELECT * FROM students");
$resGL = mysqli_fetch_assoc($gradeLevelQry);
$gradeLevel = $resGL['year'];
$section = $resGL['section'];
$spreadsheet->getActiveSheet()->setCellValue('AA4', $gradeLevel);
$spreadsheet->getActiveSheet()->setCellValue('AM4', $section);
// END get grade level

// Display Month in the file    
$spreadsheet->getActiveSheet()->setCellValue('AA3', $Month);
$spreadsheet->getActiveSheet()->setCellValue('AM42', 'Month :           '.$Month);
// END Display Month in the file

// Display total presents
$totalPresent= count($malePresent)+count($femalePresent);

//Displays Male students
$studentQry0 = mysqli_query($mysqli, "SELECT * FROM students WHERE sex = '0' ORDER BY ln, fn ASC");
$rowAt8 = "8";
$regMale=0;
$tmp=0;
$tma=0;
while($st0 = mysqli_fetch_assoc($studentQry0)){
    array_push($males, $st0['id']);
    $spreadsheet->getActiveSheet()->setCellValue('C'.$rowAt8, $st0['fn'].' '.$st0['mn'].' '.$st0['ln']);
  
    $dateQry = mysqli_query($mysqli, "SELECT *, COUNT(studentId) AS student FROM attendance WHERE faculty = '$row' AND studentId = '$st0[id]' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date");
    $totalPresents=0;
    $totalAbsents=0;
    while($res = mysqli_fetch_assoc($dateQry)){
        if($res['status']=='0'){
            $totalPresents+=1;
        }
        else{
            $totalAbsents+=1;
        }
    }
    $regMale++;
    $tmp+=$totalPresents;
    $tma+=$totalAbsents;
    $spreadsheet->getActiveSheet()->setCellValue('AO'.$rowAt8, $totalPresents);
    $spreadsheet->getActiveSheet()->setCellValue('AM'.$rowAt8, $totalAbsents);
    $rowAt8++;
}
//END displays Male 

//Displays Female students
$studentQry0 = mysqli_query($mysqli, "SELECT * FROM students WHERE sex = '1' ORDER BY ln, fn ASC");
$rowAt28="28";
$regFEMale=0;
$tfp=0;
$tfa=0;
while($st0 = mysqli_fetch_assoc($studentQry0)){
    array_push($females, $st0['id']);
    $spreadsheet->getActiveSheet()->setCellValue('C'.$rowAt28, $st0['fn'].' '.$st0['mn'].' '.$st0['ln']);
    
    $dateQry = mysqli_query($mysqli, "SELECT *,COUNT(studentId) AS student FROM attendance WHERE faculty = '$row' AND studentId = '$st0[id]' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date");
    $totalPresents=0;
    $totalAbsents=0;
    while($res = mysqli_fetch_assoc($dateQry)){
        if($res['status']=='0'){
            $totalPresents+=1;
        }
        else{
            $totalAbsents+=1;
        }
    }
    $regFEMale++;
    $tfp+=$totalPresents;
    $tfa+=$totalAbsents;
    $spreadsheet->getActiveSheet()->setCellValue('AO'.$rowAt28, $totalPresents);
    $spreadsheet->getActiveSheet()->setCellValue('AM'.$rowAt28, $totalAbsents);
    $rowAt28++;
}
//END displays Female 

//Attendance Status of Male Students//

if($fDay=="Tuesday" AND $mDay=="1"){
    for($x=0;$x<1;$x++){
        array_unshift($workdays, " ");
    }
}
if($fDay=="Wednesday" AND $mDay=="1"){
    for($x=0;$x<2;$x++){
        array_unshift($workdays, " ");
    }
}
if($fDay=="Thursday" AND $mDay=="1"){
    for($x=0;$x<3;$x++){
        array_unshift($workdays, " ");
    }
}
if($fDay=="Friday" AND $mDay=="1"){
    for($x=0;$x<4;$x++){
        array_unshift($workdays, " ");
    }
}
if($fDay=="Saturday" AND $mDay=="1"){
    for($x=0;$x<2;$x++){
        array_unshift($workdays, " ");
    }
}
if($fDay=="Saturday" AND $mDay=="1"){
    for($x=0;$x<2;$x++){
        array_shift($workdays);
    }
}
if($fDay=="Sunday" AND $mDay=="1"){
    for($x=0;$x<0;$x++){
        array_unshift($workdays, "");
    }
}

//Attendance Status of Male Students//
$noDaysClasses=0;
foreach($dates as $date){
    $rowAt8="8";
    $p=0;
    $a=0;
    foreach($males as $male){
        $dateQry = mysqli_query($mysqli, "SELECT * FROM attendance WHERE studentId = '$male' AND attendance_date = '$date' AND faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date ORDER BY attendance_date ASC");
        while($d = mysqli_fetch_assoc($dateQry)){
            $time_input = strtotime($date);
            $dt = getDate($time_input);
            $mDay = $dt['mday'];
            $letter = 0;
             $i=0;
             $n=0;
            $status; 
            if($d['status'] == '0'){  
                $i=1;  
                $p+=$i;
                $status = '';
            }
            else{
                $i=1;
                $a+=$i; 
                $status = 'x';
            }
            foreach($workdays as $workday){
                if($mDay == $workday){
                    $spreadsheet->getActiveSheet()->getStyle($columns[$letter])->getAlignment()->setHorizontal('center');
                    $spreadsheet->getActiveSheet()->getStyle($columns[$letter])->getAlignment()->setVertical('center');
                    $spreadsheet->getActiveSheet()->setCellValue($columns[$letter].$rowAt8, $status);
                    $spreadsheet->getActiveSheet()->setCellValue($columns[$letter].'27', $p);
                    $fiveAbsencesArrayMale[$male] = $d['status']; 
                }
                $letter++;
            }        
        }
        $rowAt8++;
    }

    $rowAt28="28";
    $p0=0;
    $a0=0; 
    $ttl=0;
    foreach($females as $female){
        $dateQry = mysqli_query($mysqli, "SELECT * FROM attendance WHERE studentId = '$female' AND attendance_date = '$date' AND faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date ORDER BY attendance_date DESC");   
        while($d = mysqli_fetch_assoc($dateQry)){
            $time_input = strtotime($date);
            $dt = getDate($time_input);
            $mDay = $dt['mday'];
            $letter = 0; 
            $i=0;  
            $status;
            if($d['status'] == '0'){  
                $i=1;  
                $p0+=$i;
                $status = '';          
            }
            else{
                $i=1;
                $a0+=$i;
                $status = 'x'; 
            }
            foreach($workdays as $workday){
                if($mDay == $workday){
                    $spreadsheet->getActiveSheet()->getStyle($columns[$letter])->getAlignment()->setHorizontal('center');
                    $spreadsheet->getActiveSheet()->getStyle($columns[$letter])->getAlignment()->setVertical('center');
                    $spreadsheet->getActiveSheet()->setCellValue($columns[$letter].$rowAt28, $status);
                    $spreadsheet->getActiveSheet()->setCellValue($columns[$letter].'40', $p0);
                    $spreadsheet->getActiveSheet()->setCellValue($columns[$letter].'41', $p+$p0);
                    $fiveAbsencesArrayFemale[$female] = $d['status'];   
                }
                $letter++;
            }             
        }  
        $rowAt28++;
    }
    $noDaysClasses++;
}

function fiveConsecutiveAbsences($absences, $ids){
    $absents=0;
    $count=0;
    foreach($absences as $absent => $status){
        if(($ids[$absents] == $absent) AND $status == "1"){
            $count++;
            if($count == 5){
                return true;
            }
        }
        else{
            $count = 0;
        }
        $absents++;
    }
    return false;
}
fiveConsecutiveAbsences($fiveAbsencesArrayMale, $males);
fiveConsecutiveAbsences($fiveAbsencesArrayFemale, $females);

if(fiveConsecutiveAbsences($fiveAbsencesArrayMale, $males) == true){
    $fiveAbsencesMale += 1;
}
if(fiveConsecutiveAbsences($fiveAbsencesArrayFemale, $females) == true){
    $fiveAbsencesFemale += 1;
}
$fiveAbsences = $fiveAbsencesMale+$fiveAbsencesFemale;
$spreadsheet->getActiveSheet()->setCellValue('AR57', $fiveAbsencesMale);   
$spreadsheet->getActiveSheet()->setCellValue('AS57', $fiveAbsencesFemale);   
$spreadsheet->getActiveSheet()->setCellValue('AT57', $fiveAbsences); 

$spreadsheet->getActiveSheet()->setCellValue('AO41', $tmp+$tfp);
$spreadsheet->getActiveSheet()->setCellValue('AM41', $tma+$tfa);

$spreadsheet->getActiveSheet()->setCellValue('AS50', $regFEMale);
$spreadsheet->getActiveSheet()->setCellValue('AR50', $regMale);
$totalRegSt = $regFEMale+$regMale;
$spreadsheet->getActiveSheet()->setCellValue('AT50', $totalRegSt);

if((isset($ffemale)) && (isset($fmale))){
    $spreadsheet->getActiveSheet()->setCellValue('AR44', $fmale);
    $spreadsheet->getActiveSheet()->setCellValue('AR46', $fmale);
    $spreadsheet->getActiveSheet()->setCellValue('AS44', $ffemale);
    $spreadsheet->getActiveSheet()->setCellValue('AS46', $ffemale);
    $tregStudent = $fmale + $ffemale;
    $spreadsheet->getActiveSheet()->setCellValue('AT44', $tregStudent);
    $spreadsheet->getActiveSheet()->setCellValue('AT46', $tregStudent);
}

$PoEFemale = ($regFEMale/$ffemale)*100;
$PoEMale = ($regMale/$fmale)*100;
$percentageOfEnrolment = $PoEFemale+$PoEMale;
$spreadsheet->getActiveSheet()->setCellValue('AR52', $PoEMale.'%');
$spreadsheet->getActiveSheet()->setCellValue('AS52', $PoEFemale.'%');
$spreadsheet->getActiveSheet()->setCellValue('AT52', ($percentageOfEnrolment).'%');

$ttlDailyattFemale=0;
$ttlDailyattMale=0;
if(isset($noshooldays)){
    $spreadsheet->getActiveSheet()->setCellValue('AP42', "No. of Days of Classes:   ".$noshooldays);
    // $totalFemalePresentinMonth = $tmp + $tfp;
    $ttlDailyattFemale = ($tfp/$noshooldays);
    $ttlDailyattMale = ($tmp/$noshooldays);
    $AverageDailyAttendance = $ttlDailyattFemale+$ttlDailyattMale;
    $spreadsheet->getActiveSheet()->setCellValue('AR54', $ttlDailyattMale);   
    $spreadsheet->getActiveSheet()->setCellValue('AS54', $ttlDailyattFemale);   
    $spreadsheet->getActiveSheet()->setCellValue('AT54', $AverageDailyAttendance);   
}

$pAttfortheMonthFemale = ($ttlDailyattFemale/$totalRegSt)*100;
$pAttfortheMonthMale = ($ttlDailyattMale/$totalRegSt)*100;
$percentageOfAttfortheMonth = $pAttfortheMonthFemale + $pAttfortheMonthMale;
$spreadsheet->getActiveSheet()->setCellValue('AR56', round($pAttfortheMonthMale,1));   
$spreadsheet->getActiveSheet()->setCellValue('AS56', round($pAttfortheMonthFemale,1));   
$spreadsheet->getActiveSheet()->setCellValue('AT56', round($percentageOfAttfortheMonth,1));  



$writer = new Xlsx($spreadsheet);
$writer->save('SF2.xlsx');

// count of male students that are absent in a particular month
$attendanceQry =  mysqli_query($mysqli, "SELECT * FROM attendance WHERE status = '1' AND faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date");
while($resultDate = mysqli_fetch_assoc($attendanceQry)){
    $maleCntQry = mysqli_query($mysqli, "SELECT * FROM students WHERE id = '$resultDate[studentId]' AND sex = '0'");
    $i=0;
    while($resMale = mysqli_fetch_assoc($maleCntQry)){
        $maleAbsent[$i] = $resMale['id'];
    }
}
// END count of male students that are absent in a particular month

// count of female students that are absent in a particular month
$attendanceQry =  mysqli_query($mysqli, "SELECT * FROM attendance WHERE status = '1' AND faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date");
while($resultDate = mysqli_fetch_assoc($attendanceQry)){
    $femaleCntQry = mysqli_query($mysqli, "SELECT * FROM students WHERE id = '$resultDate[studentId]' AND sex = '1'");
    $i=0;
    while($resFemale = mysqli_fetch_assoc($femaleCntQry)){
        $femaleAbsent[$i] = $resFemale['id'];
    }
}
// END count of female students that are absent in a particular month


// count of male students that are present in a particular month
$attendanceQry =  mysqli_query($mysqli, "SELECT * FROM attendance WHERE status = '0' AND faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date");
while($resultDate = mysqli_fetch_assoc($attendanceQry)){
    $maleCntQry = mysqli_query($mysqli, "SELECT * FROM students WHERE id = '$resultDate[studentId]' AND sex = '0'");
    $i=0;
    while($resMale = mysqli_fetch_assoc($maleCntQry)){
        $malePresent[$i] = $resMale['id'];
    }
}
// END count of male students that are present in a particular month

// count of female students that are present in a particular month
$attendanceQry =  mysqli_query($mysqli, "SELECT * FROM attendance WHERE status = '0' AND faculty = '$row' AND attendance_date BETWEEN '$dayOne' AND '$dayEnd' GROUP BY attendance_date");
while($resultDate = mysqli_fetch_assoc($attendanceQry)){ 
    $femaleCntQry = mysqli_query($mysqli, "SELECT * FROM students WHERE id = '$resultDate[studentId]' AND sex = '1'");
    $i=0;
    while($resFemale = mysqli_fetch_assoc($femaleCntQry)){
        $femalePresent[$i] = $resFemale['id'];
    }
}

?>