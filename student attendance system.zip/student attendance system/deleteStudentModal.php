
<div class="modal fade" id="deltStud<?php echo $rFcty['row']?>" role="dialog" data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-remove"></span>&nbsp;Delete Student Information</h4>
			</div>
			<div class="modal-body">
				<div class="alert alert-danger">
					<span class="glyphicon glyphicon-warning-sign"> </span> 
					Are you sure you want to delete this Student Account?
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-warning" onclick="deleteStud('<?php echo $rFcty['row']?>');"><span class="glyphicon glyphicon-remove"></span> Continue</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
			</div>
		</div>
	</div>
</div>