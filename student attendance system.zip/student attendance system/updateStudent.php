<?php 
    include_once 'dbConfig.php';
	require_once('loginSession.php');
		$message = "";

		$row= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['row']));
		$id= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['ids']));
		$fn = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['fn']));
		$mn = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['mn']));
		$ln = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['ln']));
		$sec = stripcslashes(mysqli_real_escape_string($mysqli, strtoupper($_POST['sec'])));
		$yr = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['yr']));
		$stmt= mysqli_stmt_init($mysqli);
		
		if($yr === 'null' || $row == 'null' || $id == 'null' || $fn == 'null' || $mn == 'null' || $ln == 'null' || $sec == 'null'){
			$message = 'Empty';
		}
		else {		
			mysqli_stmt_prepare($stmt, "UPDATE students SET id = ?, fn = ?, mn = ?, ln = ?, section = ?, year = ? WHERE row = ? ");
			mysqli_stmt_bind_param($stmt ,'sssssss' ,$id ,$fn , $mn ,$ln ,$sec, $yr, $row);
			mysqli_stmt_execute($stmt);

			$message = '<div class="alert alert-success alert-block alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Account Successfully Updated!</div>';			
		}
		
	echo $message;
	mysqli_close($mysqli);
 ?>