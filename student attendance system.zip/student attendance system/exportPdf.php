<?php
    include_once 'dbConfig.php';
    require_once('loginSession.php');
    require 'vendor/autoload.php';

    use Dompdf\Dompdf;

    $dompdf = new Dompdf();

    $row = $_POST['_faculty'];
    $grade = $_POST['_grade'];
    $subject = $_POST['_subject'];
    $date = $_POST['_date'];
    $query; 
    $status;
    $dateToday = date('M-d-Y');
    $html; 

    if($grade == null || $subject == null || $date == null){
        $query = mysqli_query($mysqli, "SELECT * FROM attendance WHERE faculty = '$row' AND attendance_date = '$dateToday' ");
        if(mysqli_num_rows($query) <= 0){
            echo "<script> history.go(-1)</script>";
            exit();
        }
    }
    else{
        $query = mysqli_query($mysqli, "SELECT * FROM attendance WHERE faculty = '$row' AND grade = '$grade' AND subject = '$subject' AND attendance_date = '$date' ");
    }

    if(isset($_POST['submit'])){

        $html = "<h3><center>Student's Attendance </center></h3>";
        $html .= "<table style='width:100%; text-align:left; font-size: 10px; border: 1px solid black; border-collapse: collapse;' >";
        $html .= '	<thead>
                        <tr>
                            <th style="width:16%;border: 1px solid black; border-collapse: collapse;" >ID</th>
                            <th style="width:45%;border: 1px solid black; border-collapse: collapse;">Student</th>
                            <th style="width:10%;border: 1px solid black; border-collapse: collapse;">Status</th>
                            <th style="width:15%;border: 1px solid black; border-collapse: collapse;">Date</th>
                            <th style="width:10%;border: 1px solid black; border-collapse: collapse;">Grade</th>
                            <th style="width:35%;border: 1px solid black; border-collapse: collapse;">Subject</th>
                        </tr>
                    </thead>
                    ';
        $html .= '  <tbody>';
        if(mysqli_num_rows($query) > 0){
            foreach($query as $q){
                $query1 = mysqli_query($mysqli, "SELECT * from students WHERE faculty = '$row' AND id = $q[studentId] ");
                $q1 = mysqli_fetch_assoc($query1);
                $query2 = mysqli_query($mysqli, "SELECT * from  subjects WHERE faculty = '$row' AND row = $q[subject] ");
                $q2 = mysqli_fetch_assoc($query2);
                if($q['status']== '0'){
                    $status='Present';
                }
                else if($q['status']== '1'){
                    $status='Absent';
                }
                else if($q['status']== '2'){
                    $status='Excused';
                }
                $html .= '
                            <tr>
                                <td style= "border: 1px solid black; border-collapse: collapse;">'.$q1['id'].'</td>
                                <td style= "border: 1px solid black; border-collapse: collapse;">'.$q1['ln'].', '.$q1['fn'].''. $q1['mn'].'</td>
                                <td style= "border: 1px solid black; border-collapse: collapse;">'.$status.'</td>
                                <td style= "border: 1px solid black; border-collapse: collapse;">'.$q['attendance_date'].'</td>
                                <td style= "border: 1px solid black; border-collapse: collapse;">Grade '.$q['grade'].'</td>
                                <td style= "border: 1px solid black; border-collapse: collapse;">'.$q2['subject'].'</td>
                            </tr>
                            ';
            }
        }
        $html .= '	</tbody>';

        $html .= "	<tfoot>
                        <tr>
                            <th style=' border: 1px solid black; border-collapse: collapse;'>ID</th>
                            <th style= 'border: 1px solid black; border-collapse: collapse;'>Student</th>
                            <th style= 'border: 1px solid black; border-collapse: collapse;'>Status</th>
                            <th style= 'border: 1px solid black; border-collapse: collapse;'>Date</th>
                            <th style= 'border: 1px solid black; border-collapse: collapse;'>Grade</th>
                            <th style= 'border: 1px solid black; border-collapse: collapse;'>Subject</th>
                        </tr>
                    </tfoot>
                    ";
    }       
    else{
        echo "<script> history.go(-1)</script>";
        exit();
    }
    $dompdf->loadHtml($html);

    // (Optional) Setup the paper size and orientation
    $dompdf->setPaper('A4', 'portrait');

    // Render the HTML as PDF
    $dompdf->render();

    // Output the generated PDF to Browser
    $dompdf->stream('Attendance'.time().'.pdf');
    
    // $html .= "  ";
    // $html .= "  ";
    // $html .= "  ";
    // $html .= "  ";
    // $html .= "  ";

    // $dompdf->loadHtml($html);
    // $dompdf->setPaper('A4', 'landscape');
    // $dompdf->render();
    // $output = $dompdf->output();
    // file_put_contents('document.pdf', $output);
?>