<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h3>Administrators</h3>
			<a type="button" class="btn btn-primary" data-toggle="modal" data-target="#addAdmin" style="margin-bottom: 10px;"><span class="glyphicon glyphicon-plus">&nbsp;</span>Add Administrator</a>
		</div>
	</div>	
	<div class="row">
		<div class="col-md-12">
			<div class="table-responsive">
			<table id="datatableAdmin" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th></th>
							<th>Username</th>
							<th>Complete Name</th>
							<th><center>Edit</center></th>
							<th><center>Delete</center></th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th></th>
							<th>Username</th>
							<th>Complete Name</th>
							<th><center>Edit</center></th>
							<th><center>Delete</center></th>
						</tr>
					</tfoot>
					<tbody>
						<?php
							$resAdmin =mysqli_query($mysqli, "SELECT * from users WHERE position = 'Administrator' ORDER BY name ASC");
								while ($rAdmn = mysqli_fetch_assoc($resAdmin)){
									echo "<tr>
											<td> $rAdmn[row] </td>
											<td> $rAdmn[username] </td>
											<td> $rAdmn[name] </td>";
									echo 	"<td>
												<center>
													<button class='btn btn-warning btn-xs' data-toggle='modal' data-target='#editAdmin".$rAdmn['row']."'>
														<span class='glyphicon glyphicon-pencil'></span> Edit
													</button>
												</center>
											</td>
											<td>
												<center>
													<button class='btn btn-danger btn-xs' data-toggle='modal' data-target='#deltAdmin".$rAdmn['row']."'>
														<span class='glyphicon glyphicon-remove'></span> Delete
													</button>
												</center>
											</td>
										</tr>";
						?>
						<?php include 'deleteAdministratorModal.php'; ?>
						<?php include 'updateAdministratorModal.php'; ?>						
						<?php				 
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php include 'addAdministratorModal.php'; ?>
<!-- <script src='Administrator.js'></script> -->
<script>
	$(document).ready(function() {
		$('#datatableAdmin').dataTable();
		 $("[data-toggle=tooltip]").tooltip();
	});
</script>

<script type="text/javascript">
	function addAdmin(){
		var data= "user="+$('#userAdmin').val()+"&pass="+$('#passAdmin').val()+"&name="+$('#nameAdmin').val();
		$.ajax({
			method:'post',
			data: data,
			url:'addAdministrator.php',
		}).done(function(data){
			// console.log(data);
			if(data == "userError"){
				$('#alertAdmn').html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Administrator was already listed!</div>');
			}
			else if(data == `isEmpty`){
				$('#alertAdmn').html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please fill all fields!</div>');
			}
			else{
				$('#addAdmin').modal('hide');
				$('.modal-backdrop').hide();
				adminTab();
				$('#alertMessage').html(data);
				hideAlert();
			}
		});
		document.body.style.overflowY = 'scroll';
	}

	function editAdmin(row){
		var rows = row;
		var data= "user="+$('#userAdmin'+rows).val()+"&pass="+$('#passAdmin'+rows).val()+"&name="+$('#nameAdmin'+rows).val()+"&row="+rows;
		$.ajax({
			method:'post',
			data: data,
			url:'updateAdministrator.php',
		}).done(function(data){
			// console.log(data);
			if(data == "userError"){
				$('#alertAdmn'+rows).html('<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Administrator was already listed!</div>');
			}
			else if(data == "isEmpty"){
				$('#alertAdmn'+rows).html('<div class="alert alert-warning alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Please fill all fields!</div>');	
			}
			else{
				$('#editAdmin'+rows).modal('hide');
				$('.modal-backdrop').hide();
				adminTab();
				$('#alertMessage').html(data);
				hideAlert();
			}
		});
		document.body.style.overflowY = 'scroll';
	}

	function deleteAdmin(row) {
		var rows = row;
		var datas = "row="+rows;
		$.ajax({
			type: "POST",
			url: "deleteAdministrator.php",
			data: datas,
		}).done(function(data){
			$('#deltAdmn'+row).modal('hide');
			$('.modal-backdrop').hide();
			adminTab();
			$('#alertMessage').html(data);
			hideAlert();
		});
		document.body.style.overflowY = 'scroll';
	}
</script>