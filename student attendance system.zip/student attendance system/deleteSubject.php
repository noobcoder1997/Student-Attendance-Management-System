<?php
	include_once 'dbConfig.php';
	require_once('loginSession.php');
	
	$message = "";

	$id = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['row']));
	$stmt = mysqli_stmt_init($mysqli);

	mysqli_stmt_prepare($stmt, "DELETE FROM subjects WHERE row = ?");
	mysqli_stmt_bind_param($stmt, 's', $id);
	mysqli_stmt_execute($stmt);

	echo $message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Subject Successfully Deleted!</div>';

	mysqli_close($mysqli);
?>