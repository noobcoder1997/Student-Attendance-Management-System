<div class="modal fade" id="editStAttendanceRecord<?php echo $r['row']?>" role="dialog" data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-pencil"></span> Edit Student's Attendance Data</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="idStud<?php echo $r['row']?>">ID<b style="color:red">*</b></label>
					<input class="form-control" value="<?php echo $r['studentId']?>" id="idStud<?php echo $r['row']?>" type="text" readonly>
				</div>
				<div class="form-group">
					<label for="nStud<?php echo $r['row']?>">Student's Name<b style="color:red">*</b></label>
					<input class="form-control" value="<?php echo $s['ln'].", ". $s['fn']." ".$s['mn'];?>" id="nStud<?php echo $r['row']?>" type="text" readonly>
				</div>
				<div class="form-group">
					<label for="sStud<?php echo $r['row']?>">Subject<b style="color:red">*</b></label>
					<select class="form-control" id="sStud<?php echo $r['row']?>">
						<option value="<?php echo $r['subject']?>" disabled><?php echo $sbjct['subject'];?></option>
						<?php 
							$sel_Sub_qry = mysqli_query($mysqli, "SELECT * FROM subjects");
							while($res_qry = mysqli_fetch_assoc($sel_Sub_qry)){
								?>
								<option value="<?php echo $res_qry['row']?>"><?php echo $res_qry['subject'];?></option>
								<?php
							}
						?>
						<option value="allSubjects">All Subjects</option>
					</select>
				</div>
				<div class="form-group">
					<label for="stsStud<?php echo $r['row']?>">Attendance Status<b style="color:red">*</b></label>
					<select class="form-control" value="<?php echo $r['status']?>" 
					id="stsStud<?php echo $r['row']?>">
					<?php 
						if($r['status'] == 0){
							?>
								<option value="0" selected disabled>Present</option>
							<?php
						} 
						if($r['status'] == 1){
							?>
						        <option value="1" selected disabled>Absent</option>
							<?php
						} 
						if($r['status'] == 2){
							?>
								<option value="2" selected disabled>Excused</option>
							<?php
						}
					?>
						<option value="0">Present</option>
						<option value="1">Absent</option>
						<option value="2">Excused</option>
					</select>
				<br>
				<script>
					$(document).ready(function() {
						$("#editStAttendance"+<?php echo $r['row']; ?>).on("hidden.bs.modal", function() {
							attendanceTab();
						})
					});
				</script>
				<span id="alertuStd<?php echo $r['row']?>"></span>
			</div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-warning btn-block" onclick="updateAttendance('<?php echo $r['row']?>');"><span class="glyphicon glyphicon-ok-sign"></span> Save Changes</button>
		</div>
	</div>
</div>
</div>
