<div class="modal fade" id="editSubModal<?php echo $_subject_['row'];?>" role="dialog" style="margin-top: 10rem;"  data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-pencil"></span> Update Student's Subject</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="sTitle<?php echo $_subject_['row']?>">Subject Title<b style="color:red">*</b></label>
					<input class="form-control" id="sTitle<?php echo $_subject_['row']?>" type="text" placeholder="Subject" required value="<?php echo $_subject_['subject']?>">
				</div>
				<div class="form-group">
					<label for="sDesc<?php echo $_subject_['row']?>">Description<b style="color:red">*</b></label>
					<input class="form-control" id="sDesc<?php echo $_subject_['row']?>" type="text" placeholder="Description" value="<?php echo $_subject_['description']?>">
				</div>
				<div class="form-group">
					<label for="sLevel<?php echo $_subject_['row']?>">Grade Level</label>
					<select class="form-control" id="sLevel<?php echo $_subject_['row']?>" type="text" placeholder="Grade Level" required>
						<option selected disabled>Grade <?php echo $_subject_['grade']?></option>
						<?php
							$resGrade = mysqli_query($mysqli, "SELECT * FROM grades");
							while($rgrade = mysqli_fetch_assoc($resGrade)){
								echo "<option value=$rgrade[grade]>Grade $rgrade[grade]</option>";	
							}
						?>
					</select>
				</div>
				<script>
					$(document).ready(function() {
						$("#editSubModal"+<?php echo $_subject_['row']; ?>).on("hidden.bs.modal", function() {
							subjectTab();
						})
					});
				</script>
				<span id="EalertSubject<?php echo $_subject_['row']?>"></span>
			</div>
			<div class="modal-footer">
				<button class="btn btn-warning btn-block" onclick="editSubject(<?php echo $_subject_['row']; ?>);"><span class="glyphicon glyphicon-ok-sign"></span> Save Changes</button>
			</div>
		</div>
	</div>
</div>