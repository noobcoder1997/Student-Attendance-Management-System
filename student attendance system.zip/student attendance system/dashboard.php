<?php
    include_once 'dbConfig.php';
	require_once('loginSession.php');
	$row = $_SESSION['row'];
	$position = $_SESSION['position'];
	$g1 = 0;$g2 = 0;$g3 = 0;$g4 = 0;$g5 = 0;$g6 = 0;
	$countUSER = '';
	if($position == 'Administrator'){$countUSER = "SELECT * FROM students WHERE faculty = $row ";}else{$countUSER = "SELECT * FROM students";}
	if (mysqli_multi_query($mysqli, $countUSER)) {
		do {
			if ($result = mysqli_store_result($mysqli)) {
				while ($cUser = mysqli_fetch_array($result)){
					if($cUser['year'] == "I")
						$g1++;
					if($cUser['year'] == "II")
						$g2++;
					if($cUser['year'] == "III")
						$g3++;
					if($cUser['year'] == "IV")
						$g4++;
					if($cUser['year'] == "V")
						$g5++;
					if($cUser['year'] == "VI")
						$g6++;
				}
				mysqli_free_result($result);
			}
		} while (mysqli_next_result($mysqli));
	}
?>
<div class="row">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-6">
				<div class="container">
					<canvas id="countChart" style="width:100%;max-width:600px"></canvas>
					<br/>
				</div>
				<br/>
			</div>
			<div class="col-md-6">
				<div class="container">
					<canvas id="subChart" style="width:100%;max-width:600px"></canvas>
					<br/>
				</div>
				<br/>
			</div>	
			<div class="col-md-6">
				<div class="container">
					<canvas id="AbsentChart" style="width:100%;max-width:600px"></canvas>
					<br/>
				</div>
				<br/>
			</div>
			<div class="col-md-6">
				<div class="container">
					<canvas id="presentChart" style="width:100%;max-width:600px"></canvas>
					<br/>
				</div>
				<br/>
			</div>
			<div class="col-md-6">
				<div class="container">
						<canvas id="attendanceChart" style="width:100%;max-width:600px"></canvas>
					<br/>
				</div>
				<br/>
			</div>
		</div>
	</div>
</div>
<script>
		var barColors = [
		"#b91d47",
		"#00aba9",
		"#2b5797",
		"#e8c3b9",
		"#1e7145",
		"#324125",
		"#114512",
		"#d25622",
		"#c23412",
		"#5f2dd2",
        "#FFA07A",
        "#ffa47e",
        "#FA8072",	
        "#E9967A",	
        "#CD5C5C",	
        "#DC143C",
        "#B22222",
        "#FF0000",	
        "#8B0000",
		"#b91d47",
		"#00aba9",
		"#2b5797",
		"#e8c3b9",
		"#1e7145",
		"#324125",
		"#114512",
		"#d25622",
		"#c23412",
		"#5f2dd2",
        "#FFA07A",
        "#ffa47e",
        "#FA8072",	
        "#E9967A",	
        "#CD5C5C",	
        "#DC143C",
        "#B22222",
        "#FF0000",	
        "#8B0000",
		"#b91d47",
		"#00aba9",
		"#2b5797",
		"#e8c3b9",
		"#1e7145",
		"#324125",
		"#114512",
		"#d25622",
		"#c23412",
		"#5f2dd2",
        "#FFA07A",
        "#ffa47e",
        "#FA8072",	
        "#E9967A",	
        "#CD5C5C",	
        "#DC143C",
        "#B22222",
        "#FF0000",	
        "#8B0000",
		"#b91d47",
		"#00aba9",
		"#2b5797",
		"#e8c3b9",
		"#1e7145",
		"#324125",
		"#114512",
		"#d25622",
		"#c23412",
		"#5f2dd2",
        "#FFA07A",
        "#ffa47e",
        "#FA8072",	
        "#E9967A",	
        "#CD5C5C",	
        "#DC143C",
        "#B22222",
        "#FF0000",	
        "#8B0000",
	];
	var xValues = ["Grade I", "Grade II", "Grade III", "Grade IV", "Grade V", "Grade VI"];
	var yValues = [<?php echo $g1;?>, <?php echo $g2;?>, <?php echo $g3;?>, <?php echo $g4;?>, <?php echo $g5;?>, <?php echo $g6;?>];

	new Chart("countChart", {
	  type: "bar",
	  data: {
		labels: xValues,
		datasets: [{
		  backgroundColor: barColors,
		  data: yValues
		}]
	  },
	  options: {
		legend: {display: false},
		title: {
		  display: true,
		  text: "Student Population"
		}
	  }
	});

/**
 * END STUDENT POPULATION
 * 
 * */	

	var xValues = [
		<?php
			$comma = 0;
			$resDepChart = '';
			if($position == "Administrator"){$resDepChart =mysqli_query($mysqli, "SELECT * from students  WHERE faculty = $row");}else{$resDepChart = mysqli_query($mysqli, "SELECT * from students ");}
			while ($dChrt = mysqli_fetch_assoc($resDepChart)){
				if($comma != 0){
					echo ",";
				}
				echo "'".$dChrt["fn"]."'";
				$comma++;
			}
		?>
	];
	
	var yValues = [
		<?php
			$current_date = date('M-d-Y');
			$comma = 0;
			$resDepChart = '';
			if($position == "Administrator"){$resDepChart =mysqli_query($mysqli, "SELECT * from students  WHERE faculty = $row");}else{$resDepChart = mysqli_query($mysqli, "SELECT * from students ");}
			while ($dChrt = mysqli_fetch_assoc($resDepChart)){
				if($comma != 0){
					echo ",";
				}
				$count = 0;
				$countDepChart = mysqli_query($mysqli, "SELECT status from attendance where studentId = '$dChrt[id]' AND status = 0 ");
				while ($cChrt = mysqli_fetch_assoc($countDepChart)){
					$count++;
				}
				echo $count;
				$comma++;
			}
		?>
	];
	
	new Chart("presentChart", {
		type: "doughnut",
		data: {
			labels: xValues,
			datasets: [{
			backgroundColor: barColors,
			data: yValues
			}]
		},
		options: {
			title: {
			display: true,
			text: "Students { Present }"
			}
		}
	});
	
// END Students that are present

	<?php
		$dateNow = date('M-d-Y');
		$countP=0;$countA=0;$countE=0;
		$attChartQuery='';
		if($position == "Administrator"){$attChartQuery =mysqli_query($mysqli, "SELECT * from attendance  WHERE faculty = $row AND attendance_date = '$dateNow' GROUP BY studentId");}
		else{$attChartQuery =mysqli_query($mysqli, "SELECT * from attendance  WHERE faculty = $row AND attendance_date = '$dateNow' GROUP BY studentId");}
		while ($aChrt = mysqli_fetch_assoc($attChartQuery)){
			if($aChrt['status'] == '0'){
				$countP++;
			}
			if($aChrt['status'] == '1'){
				$countA++;
			}
			if($aChrt['status'] == '2'){
				$countE++;
			}
		}
	?>
	var xValues = ["Present", "Absent"];
	var yValues = [<?php echo $countP; ?>,<?php echo $countA; ?>,<?php echo $countE; ?>];

	new Chart("attendanceChart", {
	  type: "bar",
	  data: {
		labels: xValues,
		datasets: [{
		  backgroundColor: barColors,
		  data: yValues
		}]
	  },
	  options: {
		legend: {display: false},
		title: {
		  display: true,
		  text: "Student Attendance Today"
		}
	  }
	});

/**
 *
 *  END STUDENT ATTENDANCE TODAY
 * 
 * */
	var xValues = [
		<?php
			$comma = 0;
			$resDepChart = '';
			if($position == "Administrator"){$resDepChart =mysqli_query($mysqli, "SELECT * from students  WHERE faculty = $row");}else{$resDepChart = mysqli_query($mysqli, "SELECT * from students ");}
			while ($dChrt = mysqli_fetch_assoc($resDepChart)){
				if($comma != 0){
					echo ",";
				}
				echo "'".$dChrt["fn"]."'";
				$comma++;
			}
		?>
	];
	
	var yValues = [
		<?php
			$current_date = date('M-d-Y');
			$comma = 0;
			$resDepChart = '';
			if($position == "Administrator"){$resDepChart =mysqli_query($mysqli, "SELECT * from students  WHERE faculty = $row ");}else{$resDepChart = mysqli_query($mysqli, "SELECT * from students ");}
			while ($dChrt = mysqli_fetch_assoc($resDepChart)){
				if($comma != 0){
					echo ",";
				}
				$count = 0;
				$countDepChart = mysqli_query($mysqli, "SELECT status from attendance where studentId = '$dChrt[id]' AND status = 1 AND attendance_date = '$current_date' ");
				while ($cChrt = mysqli_fetch_assoc($countDepChart)){
					$count++;
				}
				echo $count;
				$comma++;
			}
		?>
	];

	new Chart("AbsentChart", {
		type: "doughnut",
		data: {
			labels: xValues,
			datasets: [{
			backgroundColor: barColors,
			data: yValues
			}]
		},
		options: {
			title: {
			display: true,
			text: "Students { Absent }"
			}
		}
	});
/**
 *
 *  END STUDENT THAT ARE ABSENT
 * 
 **/	
	var xValues = [
		<?php
			$comma = 0;
			$resDepChart = '';
			if($position == "Administrator"){$resDepChart =mysqli_query($mysqli, "SELECT * from subjects WHERE faculty = $row");}else{$resDepChart = mysqli_query($mysqli, "SELECT * from subjects ");}
			while ($dChrt = mysqli_fetch_assoc($resDepChart)){
				if($comma != 0){
					echo ",";
				}
				echo "'".$dChrt["subject"]."'";
				$comma++;
			}
		?>
	];
	
	var yValues = [
		<?php
			$comma = 0;
			$resDepChart = '';
			if($position == "Administrator"){$resDepChart =mysqli_query($mysqli, "SELECT * from subjects  WHERE faculty = $row");}else{$resDepChart = mysqli_query($mysqli, "SELECT * from subjects ");}
			while ($dChrt = mysqli_fetch_assoc($resDepChart)){
				if($comma != 0){
					echo ",";
				}
				$count = 0;
				$countDepChart = mysqli_query($mysqli, "SELECT * from users where row = '$dChrt[faculty]' ");
				while ($cChrt = mysqli_fetch_assoc($countDepChart)){
					$count++;
				}
				echo $count;
				$comma++;
			}
		?>
	];

	new Chart("subChart", {
		type: "pie",
		data: {
			labels: xValues,
			datasets: [{
			backgroundColor: barColors,
			data: yValues
			}]
		},
		options: {
			title: {
			display: true,
			text: "Handled Subjects"
			}
		}
	});
	//<!-- END Handled Subjects -->
</script>
