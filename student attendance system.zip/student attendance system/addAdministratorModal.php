<div class="modal fade" id="addAdmin" role="dialog" data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true" >×</button>
				<h4 class="modal-title custom_align" id="Heading">Add an Administrator</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="userAdmin">Username<b style="color:red">*</b></label>
					<input class="form-control" id="userAdmin" type="text" placeholder="Username">
				</div>
				<div class="form-group">
					<label for="passAdmin">Password<b style="color:red">*</b></label>
					<input class="form-control" id="passAdmin" type="text" placeholder="Password">
				</div>
				<div class="form-group">
					<label for="nameAdmin">Complete Name<b style="color:red">*</b></label>
					<input class="form-control" id="nameAdmin" type="text" placeholder="Complete Name">
				</div>
				<script>				
					$(document).ready(function() {
						$("#addAdmin").on("hidden.bs.modal", function() {
						$("#addAdmin input").val('');
						});
					});
				</script>
				<span id="alertAdmn"></span>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary btn-block" onclick="addAdmin();"><span class="glyphicon glyphicon-plus"></span> Add this as Administrator</button>
			</div>
		</div>
	</div>
</div>