<?php
include_once 'dbConfig.php';

$username=htmlentities(stripcslashes(mysqli_real_escape_string($mysqli, ($_POST['username']))));
$password=htmlentities(stripcslashes(mysqli_real_escape_string($mysqli, md5(trim($_POST['password'])))));

$stmt=$mysqli->prepare("SELECT username FROM users WHERE username = ? ");
$stmt->bind_param('s', $username);
$stmt->execute();
$result=$stmt->get_result();
if($row = $result->fetch_Array(MYSQLI_ASSOC)){
    $stmt=$mysqli->prepare("UPDATE users SET password = ? WHERE username = ? ");
    $stmt->bind_param('ss',  $password, $username);
    $stmt->execute();
    echo $message=1;
}
else{
    echo $message=0;
}
$stmt->close();
?>