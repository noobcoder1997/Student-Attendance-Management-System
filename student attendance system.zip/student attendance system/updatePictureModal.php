<link rel="stylesheet" href="sas-style.css">	
	<div class="modal fade" id="imageModal" role="dialog" data-backdrop="static" data-keyboad="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-pencil"></span> Change Profile Picture</h4>
				</div>
				<div class="modal-body">
					<form action="upload.php" method="POST" role="form" enctype="multipart/form-data">
					<center>
						<label for='image' style="cursor: pointer;">
						<?php
							if($image == "" or $image == "None" or $image == 'images/default.jpg'){
						?>
							<img id="img_content" src="images/default.jpg" class="img-circle" alt="Profile Photo" height="160px;" width="160px;">
						<?php
							}
							else{
						?>
							<img id="img_content" src="<?php print_r($image);?>" class="img-circle img-display" alt="Profile Photo" height="160px;" width="160px;" style="box-shadow: 0 0 15px #A9A9A9;object-fit: cover;">						
						<?php
							}
						?>
					<br>
						Browse Pictures
						<span class="glyphicon glyphicon-camera" style="color: #A9A9A9;"></span> 
						</label>
						<input type="file" name="image" id="image" accept="image/*" style="display: none;" >
					</center>
					<input type="hidden" class="form-control" value="<?php echo $row;?>" name="row">
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn btn-default btn-block"><span class="glyphicon glyphicon-ok-sign"></span> Upload Selected Profile Picture</button>
					</form>
					<button type="button" class="btn btn-primary btn-block" onclick="cancelUpload();"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
				</div>
			</div>
		</div>
	</div>
<script>
	
	$(document).ready(function() {
		$("#imageModal").on("hidden.bs.modal", function() {
			$("#imageModal input[type='file']").val('');
			var img = document.getElementById('img_content');
    		img.src = "<?php print_r($image);?>";
		});
	});

    window.addEventListener('load', function () {
      document.querySelector('input[type="file"]').addEventListener('change', function () {
        if (this.files && this.files[0]) {
          var img = document.getElementById('img_content');
          img.onload = () => {
            URL.revokeObjectURL(img.src);
          }
          img.src = URL.createObjectURL(this.files[0]);
        }
      });
    });
    
    function cancelUpload() {
    	var img = document.getElementById('img_content');
    	img.src = "<?php print_r($image);?>";
    	$('#imageModal').modal('toggle');
    }
</script> 
<!--
<script type="text/javascript">	
	function deletePhoto(){
		var row = "<?php //echo $row;?>";
		var datas = "row="+row;
		
		$.ajax({
			type: "POST",
			url: "deletePhoto.php",
			data: datas
		}).done(function(data){
			$('#imageModal').modal('hide');
			$('.modal-backdrop').hide();
			// $('#alertMessage').html(data);
			location.replace('home.php');
			$('#alertMessage').html(data);
			hideAlert();
		});
	}
</script>-->
