<?php 
    include_once 'dbConfig.php';
	require_once('loginSession.php');
		$message = "";

		$s = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['sTitle']));
		$d = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['sDesc']));
		$l = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['sLevel']));
		$f = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['facNo']));
		$stmt = mysqli_stmt_init($mysqli);

		mysqli_stmt_prepare($stmt, "SELECT * from subjects where subject = ? AND description = ? AND grade = ? AND faculty = ? ");
		mysqli_stmt_bind_param($stmt, 'ssss', $s, $d, $l ,$f);
		mysqli_stmt_execute($stmt);
		$g = mysqli_stmt_get_result($stmt);
		if($r = mysqli_fetch_assoc($g)){
			$message = 'subjectError';
		}
		else if($s == null || $d == null || $l == null || $f == null){
			$message = 'subjectEmpty';
		}
		else{
			if(mysqli_stmt_prepare($stmt, "INSERT INTO subjects (subject, description, grade, faculty ) VALUES (?,?,?,?) ")){
				mysqli_stmt_bind_param($stmt, 'ssss', $s, $d, $l, $f);
				mysqli_stmt_execute($stmt);
				$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Subject Successfully Added!</div>';
			}else{
				$message = '<div class="alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Something went wrong!</div>';
			}
		}
		
	echo $message;
	mysqli_close($mysqli);
 ?>