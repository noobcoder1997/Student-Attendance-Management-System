<?php 
	include_once 'dbConfig.php';
	$row = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['row']));
	$position = stripcslashes(mysqli_real_escape_string($mysqli, $_SESSION['position']));
	$stmt = mysqli_stmt_init($mysqli);

	if(!empty($_FILES["image"]["tmp_name"])){
	// $folder_name=$_POST["image"]; 
	// $output_dir = @'photo'; 
	
		// if (!file_exists($output_dir . $folder_name))//checking if folder exist 
		// { 
		// 	@mkdir($output_dir . $folder_name, 0777);//making folder 
		// } 
		$fileinfo=PATHINFO($_FILES["image"]["name"]);
		$newFilename=$fileinfo['filename'] ."_". time() . "." . $fileinfo['extension'];
		move_uploaded_file($_FILES["image"]["tmp_name"],"photo/" . $newFilename);
		$location="photo/" . $newFilename; 

		if($position == "Super Administrator"){
			mysqli_stmt_prepare($stmt, "UPDATE users SET image = ? WHERE row = ?");
			mysqli_stmt_bind_param($stmt, "ss", $location, $row);
			mysqli_stmt_execute($stmt);
		}
		else if($position == "Administrator"){
			mysqli_stmt_prepare($stmt, "UPDATE users SET image = ? WHERE row = ?");
			mysqli_stmt_bind_param($stmt, "ss", $location, $row);
			mysqli_stmt_execute($stmt);
		}

		header('location:home.php');
	}
	else{
		header('location:home.php');
	}
?>