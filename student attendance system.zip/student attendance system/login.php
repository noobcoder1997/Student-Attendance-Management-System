<?php
	include_once 'dbConfig.php';
	$message = '<div class="alert alert-danger alert-dismissible">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					<span class="glyphicon glyphicon-warning-sign"></span>&nbsp;Incorrect Username or Password!
				</div>';
	
	$user = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['user']));
	$pass = stripcslashes(mysqli_real_escape_string($mysqli, md5(trim($_POST['pass']))));
	$stmt= mysqli_stmt_init($mysqli);
		
	mysqli_stmt_prepare($stmt, "SELECT * FROM users WHERE username = ? AND password = ? ");
	mysqli_stmt_bind_param($stmt, 'ss', $user, $pass);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($r = mysqli_fetch_assoc($result)){
		if(mysqli_num_rows($result) > 0){			
			$_SESSION['row'] = $r['row'];
			$_SESSION['position'] = $r['position'];
			$_SESSION['userStatus'] = true;
			$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Successfully Login!</div>';
		}
		else{
			$_SESSION['userStatus'] = false;
		}
	}

	echo $message;
	mysqli_close($mysqli);
?>