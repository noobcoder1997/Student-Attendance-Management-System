<?php 
    include_once 'dbConfig.php';
		$message = "";

		$row = stripcslashes(mysqli_real_escape_string($mysqli, $_POST['row']));
		$position = stripcslashes(mysqli_real_escape_string($mysqli, $_SESSION['position']));
		$image = 'images/default.jpg';
		$stmt = mysqli_stmt_init($mysqli);
		
		if($position == "Super Administrator"){
			mysqli_stmt_prepare($stmt, "UPDATE users SET image = ? WHERE row = ?");
			mysqli_stmt_bind_param($stmt, 'ss', $image, $row);
			mysqli_stmt_execute($stmt);
		}
		if($position == "Administrator"){
			mysqli_stmt_prepare($stmt, "UPDATE users SET image = ? WHERE row = ?");
			mysqli_stmt_bind_param($stmt, 'ss', $image, $row);
			mysqli_stmt_execute($stmt);
		}
		
		$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Photo Successfully Removed!</div>';
		
	// echo $message;
	mysqli_close($mysqli);
 ?>