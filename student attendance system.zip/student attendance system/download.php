<?php
$getfile ='SF2-'.time().'.xlsx';
$dir = "SF2.xlsx";

if (file_exists($dir)) {
$type = mime_content_type( $dir);
header('Content-Type: ' . $type);
header('Content-Disposition: attachment;filename=' . $getfile);
readfile($dir);
}
else{
echo "File Not Found";
}
?>