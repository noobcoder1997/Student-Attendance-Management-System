<?php 
    include_once 'dbConfig.php';
	require_once('loginSession.php');
		$message = "";
		$speak = "";

		$row= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['row']));
		$status= stripcslashes(mysqli_real_escape_string($mysqli, $_POST['status']));
		$subjects= explode(",",stripcslashes(mysqli_real_escape_string($mysqli, $_POST['subject'])));
		$stmt = mysqli_stmt_init($mysqli);
		
		foreach($subjects as $subject){
			mysqli_stmt_prepare($stmt, "UPDATE attendance SET status = ?, subject = ? WHERE row = ?");
			mysqli_stmt_bind_param($stmt, 'sss', $status, $subject, $row);
			mysqli_stmt_execute($stmt);
		}
		$message = '<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>Attendance Successfully Updated!</div>';
			
		$speak="<script>speakUpdateAttendance();</script>";

	echo $message;
	echo $speak;	
	mysqli_close($mysqli);
?>