
<div class="modal fade" id="AddSubModal" role="dialog" data-backdrop="static" data-keyboad="false">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title custom_align" id="Heading"><span class="glyphicon glyphicon-plus"></span> Create Student's Subject</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="sTitle">Subject Title<b style="color:red">*</b></label>
					<input class="form-control" id="sTitle" type="text" placeholder="Subject" required>
				</div>
				<div class="form-group">
					<label for="sDesc">Description<b style="color:red">*</b></label>
					<input class="form-control" id="sDesc" type="text" placeholder="Description">
				</div>
				<div class="form-group">
					<label for="sLevel">Grade Level<b style="color:red">*</b></label>
					<select class="form-control" id="sLevel" type="text" placeholder="Grade Level" required>
						<option selected disabled>Grade Level</option>
						<option value="I">Grade I</option>
						<option value="II">Grade II</option>
						<option value="III">Grade III</option>
						<option value="VI">Grade IV</option>
						<option value="V">Grade V</option>
						<option value="VI">Grade VI</option>
					</select>
				</div>
				<?php
				if($position == "Super Administrator"){
				?>
					<div class="form-group">
						<label for="sFac">Instructor<b style="color:red">*</b></label>
						<select class="form-control" id="sFac" type="text" placeholder="Instructor">
							<option value='' selected disabled>Instructor</option>
							<?php
								$facRes = mysqli_query($mysqli, "SELECT * FROM users WHERE position = 'Administrator' ");
								while ($r = mysqli_fetch_assoc($facRes)) {
									echo "<option value=$r[row]>$r[name]</option>	";
								}
							?>
						</select>
					</div>
				<?php 
				}
				?>
				<script>				
					$(document).ready(function() {
						$("#AddSubModal").on("hidden.bs.modal", function() {
						$("#AddSubModal input").val('');
						});
					});
				</script>
				<span id="alertSubject"></span>
			</div>
			<div class="modal-footer">
				<button class="btn btn-primary btn-block" onclick="addSubject();"><span class="glyphicon glyphicon-plus"></span> Add this Subject</button>
			</div>
		</div>
	</div>
</div>